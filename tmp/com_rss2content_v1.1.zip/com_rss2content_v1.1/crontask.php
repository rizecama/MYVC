<?php

/**
 * @package    Joomla
 * @subpackage Components
 * com_rss2content/crontask.php
 * @license    GNU/GPL
 * @copyright (C) 2009 rss2content.com
 * @author NenadT <nenadt@gmail.com>
 * @version $Id: rss2content.php,v 1.1 2009/07/22 Exp $
*/

defined('_JEXEC') or die();
defined('ASLOG') or define('ASLOG',0);
defined('OVERWR') or define ('OVERWR',1);
defined('IGNORE') or define ('IGNORE',2);
defined('DEFAULTCHUNK') or define ('DEFAULTCHUNK',90);

$db	=& JFactory::getDBO();
$db->setQuery("SELECT * FROM #__cron_task");
$datas=$db->loadObjectList();
$data=$datas[0];

$url = $data->executeurl;
$time = $data->timeperiod;
$fetchwith = $data->fetchwith;

$storePath = $data->storepath;
$storePath = (strlen($storePath)<0)? "./data.txt":$storePath;

$storeas= $data->storeas;
$savefull= $data->savefull;
$chunk = $data->chunksize;

$now = time();

include (JPATH_SITE."/components/com_rss2content/state.inc");

if(!isset($last) || $last=='') {
  $last = $now;
  updateState($now);
}

$secs = $now - $last;

if($secs >= $time){
  updateState($now);  
  if ($fetchwith=="1") {
    $fp=fopen(html_entity_decode($url),"rb");
    $reply="";
    if ($fp) {
	while(!feof($fp)) {
		$reply.=fread($fp,512);
	}
	fclose($fp);
    } else {
	 LogState("Failed to download/fetch","");
	 return;
    }
  } else {
	$fp = curl_init();
	$timeout = 5; // set to zero for no timeout
	curl_setopt ($fp, CURLOPT_URL, html_entity_decode($url));
	curl_setopt ($fp, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($fp, CURLOPT_CONNECTTIMEOUT, $timeout);
	$reply = curl_exec($fp);
	curl_close($fp);	
  }	
  logData($reply,$storePath,$chunk,$savefull,$storeas);
}

function updateState($time) {
 
  $filename=JPATH_SITE."/components/com_rss2content/state.inc";
  $fp=fopen($filename,"w");
  if ($fp) {
    $str="<?php \$last = '$time'; ?>\r\n";
    fwrite($fp,$str);
    fclose($fp);
  } else {
    echo "Could not open and update the file: $filename, please check permissions (should be at least 644, if fails again, try 777)";
    
  }
}

function logData($reply,$storePath,$chunk,$savefull,$storeas) {

  $ignore=false;
  switch ($storeas) {
   case ASLOG:
     $mode='a';
     break;
   case OVERWR:
     $mode='w';
     break;
   case IGNORE:
     $mode="";
     $ignore=true;
     break;
  }
  $chunk = ($chunk>0) ? $chunk:DEFAULTCHUNK;
  if ($ignore==false) {
    //echo "Saving at: $storePath\n";
    $fd=fopen($storePath,$mode);
    if ($fd) {
      if ($savefull==1) fwrite($fd,$reply); else fwrite($fd,$reply,$chunk);
      fclose($fd);
    } else {
      echo "Couldn't store the data, check file storage path and name, check permissions";
      exit(10);
    }
    
  }
}
?>
