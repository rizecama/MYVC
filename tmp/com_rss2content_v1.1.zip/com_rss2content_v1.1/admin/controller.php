<?php

/**
 * @package    Joomla
 * @subpackage Components
 * administrator/com_rss2content/controller.php
 * @license    GNU/GPL
 * @copyright (C) 2009 rss2content.com
 * @author NenadT <nenadt@gmail.com>
 * @version $Id: rss2content.php,v 1.1 2009/07/22 Exp $
*/

defined('_JEXEC') or die();
jimport('joomla.application.component.controller');


class Rss2ContentController extends JController
{
	function __construct()
	{
		parent::__construct();
		$this->registerTask('unpublish', 'publish');
		$this->registerTask('unpublishAll', 'publishAll');
		$this->registerTask('unpublishFilter', 'publishFilter');
	}
	
	function listRss(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$db	=& JFactory::getDBO();
		$db->setQuery('SELECT * FROM #__rss2content order by sectionid,categoryid');
		$rows = $db->loadObjectList();
		HTML_Rss2Content::listRss($option,$rows);
	}
	
	function showConfiguration(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$db	=& JFactory::getDBO();
		$db->setQuery('SELECT * FROM #__rss2content_config');
		$rows = $db->loadObjectList();
		$db->setQuery('SELECT * FROM #__sections');
		$sects = $db->loadObjectList();
		
		HTML_Rss2Content::showConfiguration($option,$rows[0],$sects);
	}
	
	function saveConfiguration(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		require_once(JPATH_SITE.'/administrator/components/com_rss2content/tables/rss2content_config.php');
		$post = JRequest::get('post');
		$db	=& JFactory::getDBO();
		$config=new Rss2ContentConfig($db);
		
		$textAfter=str_replace('"','',htmlentities($_REQUEST['textAfter']));
		$cat=$post['categories'];
		$categories='';
		foreach ($cat as $c)
			$categories.=$c.",";
		$categories=substr($categories,0,strlen($categories)-1);
		$twetter_sections=implode(',',$post['twetter_sections']);
		$twetter_categories=implode(',',$post['twetter_categories']);
	
	$config->id = 1;
 	$config->rsstitle = $post['rsstitle'];
 	$config->rssdesc = $post['rssdesc'];
 	$config->rssimage = $post['rssimage'];
 	$config->rssitems = $post['rssitems'];
	$config->rssitemtitle_words = $post['rssitemtitle_words'];
 	$config->rssitemdesc = $post['rssitemdesc'];
 	$config->rssitemdesc_words = $post['rssitemdesc_words'];
	$config->rssitemdesc_images= $post['rssitemdesc_images'];
	$config->link_target= $post['link_target'];
	$config->rssitemwords = $post['rssitemwords'];
	$config->no_follow = $post['no_follow'];
	$config->filter = $post['filter'];
	$config->fullTextIntro = $post['fullTextIntro'];
	$config->autoPublished = $post['autoPublished'];
	$config->frontPage = $post['frontPage'];
	$config->sectionid = null;
	$config->categoryid = $categories;
	$config->readmoreText = $post['readmoreText'];
	$config->feedsource = $post['feedsource'];
	$config->feedsourceText = $post['feedsourceText'];
	$config->archive= $post['archive'];
	$config->deleteTime = $post['deleteTime'];
	$config->timeOffset = $post['timeOffset'];
	$config->textAfter = $textAfter;
	$config->htmlTag =$post['htmlTag'];
	$config->imageNumber = $post['imageNumber'];
	$config->wordNumber = $post['wordNumber'];
	$config->modulSection = $post['modulSection'];
	$config->imageWidth = $post['imageWidth'];
	$config->imageHeight =$post['imageHeight'];
	$config->imageAlt =$post['imageAlt'];
	$config->imageClass =$post['imageClass'];
	$config->imageHspace =$post['imageHspace'];
	$config->imageVspace =$post['imageVspace'];
	$config->imageAlign =$post['imageAlign'];
	$config->imageBorder =$post['imageBorder'];
	$config->downloadImage =$post['downloadImage'];
	$config->feedImageWidth =$post['feedImageWidth'];
	$config->feedImageHeight =$post['feedImageHeight'];
	$config->twetter_username =$post['twetter_username'];
	$config->twetter_password =$post['twetter_password'];
	$config->twetter_sections =$twetter_sections;
	$config->twetter_categories =$twetter_categories;
	$config->twetter_attach =$post['twetter_attach'];
	$config->twetter_user_layer =$post['twetter_user_layer'];
	$config->aliasConnector=$post['aliasConnector'];
	$config->aliasConnectorText=$post['aliasConnectorText'];
	$config->replacements=$post['replacements'];
	$config->strip=$post['strip'];
	$config->serverTime=$post['serverTime'];
		
		if (!$config->store()) {
			JError::raiseWarning( 500, $db->getError());
		}
		else{
			$this->setMessage('Configuration Saved');
		}
		$this->setRedirect("index2.php?option=".$option."&act=conf");
	}
	
	function showFilter(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$db	=& JFactory::getDBO();
		$db->setQuery('SELECT * FROM #__sections');
		$rows = $db->loadObjectList();
		HTML_Rss2Content::showFilter($option,$rows);
	}
	
	function newFilter(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$db	=& JFactory::getDBO();
		$db->setQuery('SELECT * FROM #__sections');
		$rows = $db->loadObjectList();
		HTML_Rss2Content::newFilter($option,$rows);
	}
	
	function saveNewFilter(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$post = JRequest::get('post');
		$filters=$post['filters'];
		$db	=& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__rss2content_config");
		$rows=$db->loadObjectList();
		$row=$rows[0];
		$published=$row->autoPublished;
		$allRights=true;
		$section=$post['section'];
		for ($i=0;$i<count($filters);$i++){
			$db->setQuery("INSERT INTO #__rss2content_filter VALUES (NULL,'".$filters[$i]."','".$post['section']."','".$post['category'.$section]."','".$published."')");
			if (!$db->query()) {
				JError::raiseWarning( 500, $db->getError());
				$allRights=false;
			}
		}
		if($allRights){
			$this->setMessage('New filter saved');
			$this->setRedirect("index2.php?option=".$option."&act=filter&category".$section."=".$_REQUEST['category'.$section]."&section=".$_REQUEST['section']);
		}
		else{
			JError::raiseWarning( 500, $db->getError() );
			$this->setRedirect("index2.php?option=".$option."&act=filter&task=newFilter&category".$section."=".$_REQUEST['category'.$section]."&section=".$_REQUEST['section']);
		}
		
	}
	
	function editFilter(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$post = JRequest::get('post');
		$cid = JRequest::getVar('cid', array(), 'request', 'array');
		$db	=& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__rss2content_filter WHERE id='".$cid[0]."'");
		$rows=$db->loadObjectList();
		HTML_Rss2Content::editFilter($option,$rows[0]);
	}
	
	function saveEditFilter(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$post = JRequest::get('post');
		$db	=& JFactory::getDBO();
		$section=$_REQUEST['section'];
		$db->setQuery("UPDATE #__rss2content_filter SET filtertext='".$post['filter']."', published='".$post['published']."' WHERE id='".$post['id']."'");
		if(!$db->query()){
			JError::raiseWarning( 500, $db->getError() );
		}
		else{
			$this->setMessage('Filter changed');
			$this->setRedirect("index2.php?option=".$option."&act=filter&category".$section."=".$_REQUEST['category'.$section]."&section=".$_REQUEST['section']);
		}		
	}
	
	function deleteFilter(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$post = JRequest::get('post');
		$cid = JRequest::getVar('cid', array(), 'request', 'array');
		$db	=& JFactory::getDBO();
		$section=$_REQUEST['section'];
		$db->setQuery("DELETE FROM #__rss2content_filter WHERE id IN (" . implode( ',', $cid ).")");
		if (!$db->query()) {
			JError::raiseWarning( 500, $db->getError());
		}
		else{
			if(count($cid)>1)
				$mess="s";
			else
				$mess="";
			$this->setMessage('Filter'.$mess.' deleted');
			$this->setRedirect("index2.php?option=".$option."&act=filter&category".$section."=".$_REQUEST['category'.$section]."&section=".$_REQUEST['section']);
		}	
	}

	function publishFilter(){
		$option = JRequest::getCmd('option');
		$cid = JRequest::getVar('cid', array(), 'request', 'array');
		if ($this->getTask() == 'publishFilter') {
			$publish = 1;
			$action='published';
		} else {
			$publish = 0;
			$action='unpublished';
		}
		$section=$_REQUEST['section'];
		$db	=& JFactory::getDBO();
		$db->setQuery( "UPDATE #__rss2content_filter SET published='".$publish."'"
		. "\nWHERE id IN (" . implode( ',', $cid ).")");
		if (!$db->query()) {
				JError::raiseWarning( 500, $db->getError() );
		}
				
		$this->setRedirect("index2.php?option=".$option."&act=filter&category".$section."=".$_REQUEST['category'.$section]."&section=".$_REQUEST['section']);
		
		if (count($cid) > 1) {
			$s = 's';
		} else {
			$s = '';
		}
		
		$this->setMessage('Field' . $s . ' ' . $action);
	}
	
	function showRss(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$db	=& JFactory::getDBO();
		$db->setQuery('SELECT * FROM #__sections');
		$rows = $db->loadObjectList();
		HTML_Rss2Content::showRss($option,$rows);
	}
	
	function newRss(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$db	=& JFactory::getDBO();
		$db->setQuery('SELECT * FROM #__sections');
		$rows = $db->loadObjectList();
		$db->setQuery('SELECT * FROM #__users WHERE block=0');
		$users = $db->loadObjectList();
		HTML_Rss2Content::newRss($option,$rows,$users);
	}
	
	function saveNewRss(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$post = JRequest::get('post');
		$rsss=$post['rsss'];
		$user=$post['user'];
		$db	=& JFactory::getDBO();
		$allRights=true;
		$db->setQuery("SELECT * FROM #__rss2content_config");
		$rows=$db->loadObjectList();
		$row=$rows[0];
		$published=$row->autoPublished;
		$section=$post['section'];
		$db->setQuery("SELECT * FROM #__rss2content WHERE sectionid='".$post['section']."' AND categoryid='".$post['category'.$section]."' ORDER BY ordering desc limit 1");
		$rows = $db->loadObjectList();
		if(count($rows)==0){
			$ordering=1;
		}else{
			$row=$rows[0];
			$ordering=$row->ordering+1;
		}
		$secton=$post['section'];
		for ($i=0;$i<count($rsss);$i++){
			$db->setQuery("INSERT INTO #__rss2content VALUES (NULL,'".$rsss[$i]."','".$user[$i]."',".$post['section'].",".$post['category'.$section].",".$ordering.",".$published.")");
			 
			if (!$db->query()) {
				JError::raiseWarning( 500, $db->getError()."INSERT INTO #__rss2content VALUES (NULL,'".$rsss[$i]."','".$user[$i]."',".$post['section'].",".$post['category'.$section].",".$ordering.",".$published.")" );
				$allRights=false;
			}
			$ordering++;
		}
		if($allRights){
			$this->setMessage('New rss saved');
			$this->setRedirect("index2.php?option=".$option."&act=rss&category".$section."=".$_REQUEST['category'.$section]."&section=".$_REQUEST['section']);
		}
		else{
			JError::raiseWarning( 500, $db->getError() );
			$this->setRedirect("index2.php?option=".$option."&act=rss&task=newRss&category".$section."=".$_REQUEST['category'.$section]."&section=".$_REQUEST['section']);
		}
	}
	
	function editRss(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$post = JRequest::get('post');
		$cid = JRequest::getVar('cid', array(), 'request', 'array');
		$db	=& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__rss2content WHERE id='".$cid[0]."'");
		$rows=$db->loadObjectList();
		HTML_Rss2Content::editRss($option,$rows[0]);
	}
	
	function saveEditRss(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$post = JRequest::get('post');
		$db	=& JFactory::getDBO();
		$section=$_REQUEST['section'];
		$db->setQuery("UPDATE #__rss2content SET url='".$post['url']."', published='".$post['published']."',ordering='".$post['ordering']."' WHERE id='".$post['id']."'");
		if(!$db->query()){
			JError::raiseWarning( 500, $db->getError() );
		}
		else{
			$this->setMessage('Rss changed');
			$this->setRedirect("index2.php?option=".$option."&act=rss&category=".$section."".$_REQUEST['category'.$section]."&section=".$_REQUEST['section']);
		}
	}
	
	function deleteRss(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$post = JRequest::get('post');
		$cid = JRequest::getVar('cid', array(), 'request', 'array');
		$db	=& JFactory::getDBO();
		$section=$_REQUEST['section'];
		$db->setQuery("DELETE FROM #__rss2content WHERE id IN (" . implode( ',', $cid ).")");
		if (!$db->query()) {
			JError::raiseWarning( 500, $db->getError());
		}
		else{
			
			$this->setMessage('Rss deleted');
			$this->setRedirect("index2.php?option=".$option."&act=rss&category".$section."=".$_REQUEST['category'.$section]."&section=".$_REQUEST['section']);
		}	
	}
	
	function deleteRssAll(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$post = JRequest::get('post');
		$cid = JRequest::getVar('cid', array(), 'request', 'array');
		$db	=& JFactory::getDBO();
		$section=$_REQUEST['section'];
		$db->setQuery("DELETE FROM #__rss2content WHERE id IN (" . implode( ',', $cid ).")");
		if (!$db->query()) {
			JError::raiseWarning( 500, $db->getError());
		}
		else{
			
			$this->setMessage('Rss deleted');
			$this->setRedirect("index2.php?option=".$option."&act=list");
		}	
	}
	
	function publish(){
		$option = JRequest::getCmd('option');
		$cid = JRequest::getVar('cid', array(), 'request', 'array');
		if ($this->getTask() == 'publish') {
			$publish = 1;
			$action='published';
		} else {
			$publish = 0;
			$action='unpublished';
		}
		$section=$_REQUEST['section'];
		$db	=& JFactory::getDBO();
		$db->setQuery( "UPDATE #__rss2content SET published='".$publish."'"
		. "\nWHERE id IN (" . implode( ',', $cid ).")");
		if (!$db->query()) {
				JError::raiseWarning( 500, $db->getError() );
		}
				
		$this->setRedirect("index2.php?option=".$option."&act=rss&category".$section."=".$_REQUEST['category'.$section]."&section=".$_REQUEST['section']);
		
		$this->setMessage('Rss '.$action);
	}
	
	function publishAll(){
		$option = JRequest::getCmd('option');
		$cid = JRequest::getVar('cid', array(), 'request', 'array');
		if ($this->getTask() == 'publishAll') {
			$publish = 1;
			$action='published';
		} else {
			$publish = 0;
			$action='unpublished';
		}
		
		$db	=& JFactory::getDBO();
		$db->setQuery( "UPDATE #__rss2content SET published='".$publish."'"
		. "\nWHERE id IN (" . implode( ',', $cid ).")");
		if (!$db->query()) {
				JError::raiseWarning( 500, $db->getError() );
		}
				
		$this->setRedirect("index2.php?option=".$option."&act=list");
		
		$this->setMessage('Rss '.$action);
	}
	
	function orderUp(){
		$option = JRequest::getCmd('option');
		$db	=& JFactory::getDBO();
		$cid = JRequest::getVar('cid', array(), 'request', 'array');
			
		$db->setQuery("SELECT * FROM #__rss2content WHERE id='".$cid[0]."'");
		$rows = $db->loadObjectList();
		$row=$rows[0];
		$current=$row->ordering;
		$newValue=$current-1;
		
		$section=$_REQUEST['section'];
		$category=$_REQUEST['category'.$section];
		
		$db->setQuery("UPDATE #__rss2content SET ordering='".$current."' WHERE ordering='".$newValue."' AND sectionid='".$section."' AND categoryid='".$category."'");
		if (!$db->query()) {
			JError::raiseWarning( 500, $db->getError() );
		}
		
		$db->setQuery("UPDATE #__rss2content SET ordering='".$newValue."' WHERE id='".$cid[0]."' AND sectionid='".$section."' AND categoryid='".$category."'");
		if (!$db->query()) {
			JError::raiseWarning( 500, $db->getError() );
		}
		$this->setRedirect("index2.php?option=".$option."&act=rss&category".$section."=".$_REQUEST['category'.$section]."&section=".$_REQUEST['section']);
		
	}
	
	function orderDown(){
		$option = JRequest::getCmd('option');
		$db	=& JFactory::getDBO();
		$cid = JRequest::getVar('cid', array(), 'request', 'array');
			
		$db->setQuery("SELECT * FROM #__rss2content WHERE id='".$cid[0]."'");
		$rows = $db->loadObjectList();
		$row=$rows[0];
		$current=$row->ordering;
		$newValue=$current+1;
		
		$section=$_REQUEST['section'];
		$category=$_REQUEST['category'.$section];
		
		$db->setQuery("UPDATE #__rss2content SET ordering='".$current."' WHERE ordering='".$newValue."' AND sectionid='".$section."' AND categoryid='".$category."'");
		if (!$db->query()) {
			JError::raiseWarning( 500, $db->getError() );
		}
		
		$db->setQuery("UPDATE #__rss2content SET ordering='".$newValue."' WHERE id='".$cid[0]."' AND sectionid='".$section."' AND categoryid='".$category."'");
		if (!$db->query()) {
			JError::raiseWarning( 500, $db->getError() );
		}
		$this->setRedirect("index2.php?option=".$option."&act=rss&category".$section."=".$_REQUEST['category'.$section]."&section=".$_REQUEST['section']);
	}
	
	function saveOrder(){
		$option = JRequest::getCmd('option');
		$db	=& JFactory::getDBO();
		$cid = JRequest::getVar('cid', array(), 'request', 'array');
		
		$order=$_REQUEST['order'];
		$section=$_REQUEST['section'];
		for($i=0;$i<count($cid);$i++){
			$db->setQuery("UPDATE #__rss2content SET ordering='".$order[$i]."' WHERE id='".$cid[$i]."'");
			if (!$db->query()) {
				JError::raiseWarning( 500, $db->getError());
			}
		}
		$this->setRedirect("index2.php?option=".$option."&act=rss&category".$section."=".$_REQUEST['category'.$section]."&section=".$_REQUEST['section']);
		
	}

	function getFeed()
	{
		ini_set("max_execution_time","99999");
		require_once(JPATH_SITE.'/administrator/components/com_rss2content/tables/content.php');
		require_once(JPATH_SITE.'/administrator/components/com_rss2content/tables/rss2content_articles.php');
		$db	=& JFactory::getDBO();
		$content=new Content($db);
		$articles=new Rss2ContentArticles($db);
		$db->setQuery("SELECT * FROM #__rss2content_config");
		$rows = $db->loadObjectList();
		$row=$rows[0];
		
		//global $mainframe;
		$rss = array(); //init feed array
		if(!class_exists('SimplePie')){
			//include Simple Pie processor class
			require_once (JPATH_SITE.DS.'libraries'.DS.'simplepie'.DS.'simplepie.php');
		}
		
				
		$rssitems 		= $row->rssitems;
		$rssdesc 		= $row->rssdesc;
		$rssimage 		= $row->rssimage;
		$rssitemtitle_words 	= $row->rssitemtitle_words;
		$rssitemdesc		= $row->rssitemdesc;
		$rssitemdesc_images	= $row->rssitemdesc_images;
		$rssitemdesc_words	= $row->rssitemdesc_words;
		$rsstitle		= $row->rsstitle;
		$link_target		= $row->link_target;
		$rssitemwords=$row->rssitemwords;
		$no_follow		= $row->no_follow;	
		$filter     	= $row->filter;
		$frontPage	= $row->frontPage;
		$sectionid=$row->sectionid;
		$categoryid=$row->categoryid;
		$categories=explode(",",$categoryid);
		$timeToArchive=$row->archive;
		$timeOffset=$row->timeOffset;
		$deleteTime=$row->deleteTime;
		$textAfter=htmlspecialchars_decode($row->textAfter);
		$htmlTag=$row->htmlTag;
		$imageWidthTemp=$row->imageWidth;
		$imageHeightTemp=$row->imageHeight;
		$imageAlt=$row->imageAlt;
		$imageClass=$row->imageClass;
		$imageHspace=$row->imageHspace;
		$imageVspace=$row->imageVspace;
		$imageAlign=$row->imageAlign;
		$imageBorder=$row->imageBorder;
		$downloadImage=$row->downloadImage;		
		$feedImageWidthTemp=$row->feedImageWidth;
		$feedImageHeightTemp=$row->feedImageHeight;
		$readmoreText=$row->readmoreText;
		$feedsource=$row->feedsource;
		$feedsourceText=$row->feedsourceText;
		$fullTextIntro=$row->fullTextIntro;
		$autoPublished=$row->autoPublished;
		
		$twetter_username=$row->twetter_username;
		$twetter_password=$row->twetter_password;
		$twetter_sections=$row->twetter_sections;
		$twetter_categories=$row->twetter_categories;
		$twetter_attach=$row->twetter_attach;
		$twetter_user_layer=$row->twetter_user_layer;
		
		$aliasConnector=$row->aliasConnector;
		$aliasConnectorText=$row->aliasConnectorText;
		$strip=$this->getStripCharList($row->strip);
		$replacements=$this->getReplacements($row->replacements);
		$serverTime=$row->serverTime;
		
		$server_root=JPATH_ROOT;
		
		$this->archiveFeed($timeToArchive);
		$this->deleteFeeds($deleteTime);
		
		$db->setQuery("SELECT * FROM #__rss2content WHERE published='1' ORDER BY ordering");
		$rows = $db->loadObjectList();
		
		$numberOfRss=0;
		$feeds=array();
		$downloaded=array();
		$twittered=array();
		$successIndex=0;
		
		
		if(count($rows)==0){
			$error = 'Invalid feed url. Please enter a valid url.';
			return $rss; //halt if no valid feed url supplied
		}
		else{
			
			for($z=0;$z<count($rows);$z++){
				$downloadedIndex=0;
				$twitteredIndex=0;
				$feedImageWidth=$feedImageWidthTemp;
				$feedImageHeight=$feedImageHeightTemp;
				$imageurl = "";
				$imagetitle = "";
				$row=$rows[$z];
				$db->setQuery("SELECT * FROM #__content WHERE sectionid='".$row->sectionid."' and catid='".$row->categoryid."' ORDER BY ordering DESC LIMIT 1");
				$zzs=$db->loadObjectList();
				if(count($zzs)>0){
					$zz=$zzs[0];
					$ordering=$zz->ordering+1;
				}
				else{
					$ordering=1;
				}
				
				$filters=array();
				$db->setQuery("SELECT * FROM #__rss2content_filter WHERE sectionid='".$row->sectionid."' and categoryid='".$row->categoryid."' AND published='1'");
				$fils=$db->loadObjectList();
				for($u=0;$u<count($fils);$u++){
					$fil=$fils[$u];
					$filters[]=strtoupper($fil->filtertext);
				}
				
				$rssurl=$row->url;
				$feeds[$successIndex]=$row->url;
				switch($link_target){ //open links in current or new window
					case 1:
						$link_target='_blank';
						break;
					case 0:
						$link_target='_self';
						break;
					default:
						$link_target='_blank';
						break;
				}
		
				if($no_follow){
					$nofollow = 'rel="rokbox"';
				}
		
				//Load and build the feed array
				$feed = new SimplePie();
				$feed->set_cache_location(JPATH_SITE.'/cache');
				$feed->set_feed_url($rssurl);
				$feed->set_enclosure_class('SimplePie_Enclosure');
				//check and set caching
		

				$feed->init(); //process the loaded feed
				$feed->handle_content_type();
					//store any error message
				if (isset($feed->error)) {
					$error = $feed->error;
				}
			
				//start building the feed meta-info (title, desc and image)
				// feed title			
				if ($rsstitle ) {
					$titlelink = $feed->get_link();
					$titletitle = $feed->get_title();
				}
				// feed description
				
				if ( $rssdesc ) {
					$description = $feed->get_description();
					
				}
				
				// feed image
				if ( $rssimage && $feed->get_image_url() ) {
					if($this->downloadYesNo($feed->get_image_url())){
						$name=$this->downloadLogo($feed->get_image_url(),JPATH_SITE);
						$imageurl ='images'."/rss2content/".$name;
					
						if((empty($feedImageWidth) || $feedImageWidth=="" || $feedImageWidth==0) && (!empty($feedImageHeight) || $feedImageHeight!="" || $feedImageHeight!=0)){
							if(file_exists(JPATH_SITE.'/images/rss2content/'.$name)){
								$image_info = getimagesize(JPATH_SITE.'/images/rss2content/'.$name);
		      					$image_type = $image_info[2];
		      					if( $image_type == IMAGETYPE_JPEG ) {
		         					$image = imagecreatefromjpeg(JPATH_SITE.'/images/rss2content/'.$name);
		      					} elseif( $image_type == IMAGETYPE_GIF ) {
									$image = imagecreatefromgif(JPATH_SITE.'/images/rss2content/'.$name);
								} elseif( $image_type == IMAGETYPE_PNG ) {
									$image = imagecreatefrompng(JPATH_SITE.'/images/rss2content/'.$name);
							    }
								$ratio = $feedImageHeight/imagesy($image);
		      					$feedImageWidth = imagesx($image) * $ratio;
		      				}
	      					
	      				}
						elseif((!empty($feedImageWidth) || $feedImageWidth!="" || $feedImageWidth!=0) && (empty($feedImageHeight) || $feedImageHeight=="" || $feedImageHeight==0)){
							if(file_exists(JPATH_SITE.'/images/rss2content/'.$name)){
								$image_info = getimagesize(JPATH_SITE.'/images/rss2content/'.$name);
		      					$image_type = $image_info[2];
		      					if( $image_type == IMAGETYPE_JPEG ) {
		         					$image = imagecreatefromjpeg(JPATH_SITE.'/images/rss2content/'.$name);
		      					} elseif( $image_type == IMAGETYPE_GIF ) {
									$image = imagecreatefromgif(JPATH_SITE.'/images/rss2content/'.$name);
								} elseif( $image_type == IMAGETYPE_PNG ) {
									$image = imagecreatefrompng(JPATH_SITE.'/images/rss2content/'.$name);
								}
								$ratio = $feedImageWidth/imagesx($image);
		      					$feedImageHeight = imagesy($image) * $ratio;
		      				}
						}
						elseif((empty($feedImageWidth) || $feedImageWidth=="" || $feedImageWidth==0) && (empty($feedImageHeight) || $feedImageHeight=="" || $feedImageHeight==0)){
							if(file_exists(JPATH_SITE.'/images/rss2content/'.$name)){
								$image_info = getimagesize(JPATH_SITE.'/images/rss2content/'.$name);
		      					$image_type = $image_info[2];
		      					if( $image_type == IMAGETYPE_JPEG ) {
		         					$image = imagecreatefromjpeg(JPATH_SITE.'/images/rss2content/'.$name);
		      					} elseif( $image_type == IMAGETYPE_GIF ) {
									$image = imagecreatefromgif(JPATH_SITE.'/images/rss2content/'.$name);
								} elseif( $image_type == IMAGETYPE_PNG ) {
									$image = imagecreatefrompng(JPATH_SITE.'/images/rss2content/'.$name);
								}
								$feedImageWidth = imagesx($image);
								$feedImageHeight=imagesy($image);
							}
								
						}
					}
					$imagetitle = $feed->get_image_title();
				}
				
					
				//end feed meta-info
		
				//start processing feed items
				//if there are items in the feed
				
				if($feed->get_item_quantity()){	
					
				//start looping through the feed items
					$slick_rss_item = 0; //item counter for array indexing in the loop
					$x="show_title=
link_titles=
show_intro=
show_section=
link_section=
show_category=
link_category=
show_vote=
show_author=
show_create_date=
show_modify_date=
show_pdf_icon=
show_print_icon=
show_email_icon=
language=
keyref=
readmore=";
					foreach ($feed->get_items(0, $rssitems) as $currItem) {
						
						// item title							
						$item_title = trim($currItem->get_title());
						if(!empty($strip))
							$item_title=str_replace( $strip, '', $item_title);
						if(!empty($replacements))
							$item_title=strtr($item_title,$replacements);
						$title_alias=$item_title;
						$rssitemlink='';
						$desc='';
						$rest='';
						
						// item title word limit check
						if ( $rssitemtitle_words ) {
							
							$item_titles = explode( ' ', $item_title );
							$it=str_split($item_title);
							$t=$item_titles;
							$count = count( $it );
							if ( $count > $rssitemtitle_words ) {
								$item_title = '';
								for( $j=0; $j < $rssitemtitle_words; $j++ ) {
									$item_title .= $it[$j];
								}
								$item_title .= '...';
							}
							
							$count = count( $item_titles );
							
							if ( $count > $rssitemtitle_words ) {
								$title_alias = '';
								for( $j=0; $j < $rssitemtitle_words; $j++ ) {
									$title_alias .= ' '. $item_titles[$j];
								}
								$title_alias .= '...';
							}
						}
						
						
						if($aliasConnector==1){
							$alias=str_replace(" ",$aliasConnectorText,$title_alias);
						}
						else{
							$alias=$title_alias;
						}
						
						$intro_text='';
						if($feed->get_title() && $rsstitle==1){
							$intro_text.='<a href="'.$titlelink.'" target="'.$link_target.'">'.$titletitle.'&nbsp;>>&nbsp;</a><br>';
						}
						if ( $rssdesc) {							
							$intro_text.=$description.'<br>';
						}
						
						if ( $rssimage==1 ) {
							$intro_text.='<div align="right"><br><img src="'.$imageurl.'"';
							if(strlen($feedImageWidth)>0)
								$intro_text.=' width="'.$feedImageWidth.'"';
							if(strlen($feedImageHeight))
								$intro_text.=' height="'.$feedImageHeight.'"';
							$intro_text.=' /><br>';
							
							if($feedsource==1)
								$intro_text.='<strong>'.$feedsourceText.'</strong> '.$imagetitle.'  </div>';
							else
								$intro_text.='</div>';
						}	
						
						// Item Title
						$rssitemlink = $currItem->get_permalink();
						$temp='';
						// item description
						if($rssitemdesc){
							$desc = trim($currItem->get_description());
							if(!empty($strip))
								$desc=str_replace( $strip, '', $desc);
							if(!empty($replacements))
								$desc=strtr($desc,$replacements);
								
							if(!$rssitemdesc_images){
								$desc = preg_replace("/<img[^>]+\>/i", "", $desc); //strip image tags
							}	
				
							//item description word limit check
							if ( $rssitemdesc_words >0) {
								
								if(strstr($desc,'<img')){
									
									preg_match_all('/<img[^>]+>/i',$desc, $result); 
									$pic='';
									$newName='';
									foreach($result as $result1)
									{					
										foreach( $result1 as $img_tag)
										{
   											preg_match('/(src)=("[^"]*")/i',$img_tag, $img);
   											$pic=str_replace('"','',$img[2]);
											if($this->downloadYesNo($pic)){
												$imageWidth=$imageWidthTemp;
												$imageHeight=$imageHeightTemp;
												
												if($downloadImage=='1'){
													$newName=$this->downloadPictures($pic,JPATH_SITE);
													$newName=str_replace("%","",$newName);
												
													if((empty($imageWidth) || $imageWidth=="" || $imageWidth==0) && (!empty($imageHeight) || $imageHeight!="" || $imageHeight!=0)){
														$image_info = getimagesize(JPATH_SITE.'/images/rss2content/'.$newName);
	      												$image_type = $image_info[2];
	      												if( $image_type == IMAGETYPE_JPEG ) {
	         												$image = imagecreatefromjpeg(JPATH_SITE.'/images/rss2content/'.$newName);
	      												} elseif( $image_type == IMAGETYPE_GIF ) {
													        $image = imagecreatefromgif(JPATH_SITE.'/images/rss2content/'.$newName);
													    } elseif( $image_type == IMAGETYPE_PNG ) {
													        $image = imagecreatefrompng(JPATH_SITE.'/images/rss2content/'.$newName);
													    }
													    
														$ratio = $imageHeight/imagesy($image);
	      												$imageWidth = imagesx($image) * $ratio;
	      												
													}
													elseif((!empty($imageWidth) || $imageWidth!="" || $imageWidth!=0) && (empty($imageHeight) || $imageHeight=="" || $imageHeight==0)){
														$image_info = getimagesize(JPATH_SITE.'/images/rss2content/'.$newName);
	      												$image_type = $image_info[2];
	      												if( $image_type == IMAGETYPE_JPEG ) {
	         												$image = imagecreatefromjpeg(JPATH_SITE.'/images/rss2content/'.$newName);
	      												} elseif( $image_type == IMAGETYPE_GIF ) {
													        $image = imagecreatefromgif(JPATH_SITE.'/images/rss2content/'.$newName);
													    } elseif( $image_type == IMAGETYPE_PNG ) {
													        $image = imagecreatefrompng(JPATH_SITE.'/images/rss2content/'.$newName);
													    }
													    
														$ratio = $imageWidth/imagesx($image);
	      												$imageHeight = imagesy($image) * $ratio;
													}
													elseif((empty($imageWidth) || $imageWidth=="" || $imageWidth==0) && (empty($imageHeight) || $imageHeight=="" || $imageHeight==0)){
														$image_info = getimagesize(JPATH_SITE.'/images/rss2content/'.$newName);
	      												$image_type = $image_info[2];
	      												if( $image_type == IMAGETYPE_JPEG ) {
	         												$image = imagecreatefromjpeg(JPATH_SITE.'/images/rss2content/'.$newName);
	      												} elseif( $image_type == IMAGETYPE_GIF ) {
													        $image = imagecreatefromgif(JPATH_SITE.'/images/rss2content/'.$newName);
													    } elseif( $image_type == IMAGETYPE_PNG ) {
													        $image = imagecreatefrompng(JPATH_SITE.'/images/rss2content/'.$newName);
													    }
													    $imageWidth=imagesx($image);
														$imageHeight = imagesy($image);
													}
													
													$te='<img src="images/rss2content/'.$newName.'" hspace="'.$imageHspace.'"';
													if(strlen($imageHeight)>0)
														$te.=' height="'.$imageHeight.'"';
													if(strlen($imageWidth)>0)
														$te.=' width="'.$imageWidth.'"';
													
													$te.=' alt="'.$imageAlt.'" class="'.$imageClass.'" vspace="'.$imageVspace.'" align="'.$imageAlign.'" border="'.$imageBorder.'">';
												
												}
												else{
													if((empty($imageWidth) || $imageWidth=="" || $imageWidth==0) && (!empty($imageHeight) || $imageHeight!="" || $imageHeight!=0)){
														$aContext = array('http' => array('request_fulluri' => True));
														$cxContext = stream_context_create($aContext);
														if(strstr($pic,"?"))
															$pic=substr($pic,0,strpos($pic,"?"));
														if(strlen($pic)>0){
															file_put_contents(JPATH_SITE."/images/rss2content/image.jpg", file_get_contents($pic, False, $cxContext));
															$image_info = getimagesize(JPATH_SITE."/images/rss2content/image.jpg");
		      												$image_type = $image_info[2];
		      												if( $image_type == IMAGETYPE_JPEG ) {
		         												$image = imagecreatefromjpeg(JPATH_SITE."/images/rss2content/image.jpg");
		      												} elseif( $image_type == IMAGETYPE_GIF ) {
														        $image = imagecreatefromgif(JPATH_SITE."/images/rss2content/image.jpg");
														    } elseif( $image_type == IMAGETYPE_PNG ) {
														        $image = imagecreatefrompng(JPATH_SITE."/images/rss2content/image.jpg");
														    }
														    unlink(JPATH_SITE."/images/rss2content/image.jpg");
															$ratio = $imageHeight/imagesy($image);
		      												$imageWidth = imagesx($image) * $ratio;
														}      												
													}
													elseif ((!empty($imageWidth) || $imageWidth!="" || $imageWidth!=0) && (empty($imageHeight) || $imageHeight=="" || $imageHeight==0)){
														$aContext = array('http' => array('request_fulluri' => True));
														$cxContext = stream_context_create($aContext);
														if(strstr($pic,"?"))
															$pic=substr($pic,0,strpos($pic,"?"));
														if(strlen($pic)>0){
															file_put_contents(JPATH_SITE."/images/rss2content/image.jpg", file_get_contents($pic, False, $cxContext));
															$image_info = getimagesize(JPATH_SITE."/images/rss2content/image.jpg");
		      												$image_type = $image_info[2];
		      												if( $image_type == IMAGETYPE_JPEG ) {
		         												$image = imagecreatefromjpeg(JPATH_SITE."/images/rss2content/image.jpg");
		      												} elseif( $image_type == IMAGETYPE_GIF ) {
														        $image = imagecreatefromgif(JPATH_SITE."/images/rss2content/image.jpg");
														    } elseif( $image_type == IMAGETYPE_PNG ) {
														        $image = imagecreatefrompng(JPATH_SITE."/images/rss2content/image.jpg");
														    }
														    unlink(JPATH_SITE."/images/rss2content/image.jpg");
															$ratio = $imageWidth/imagesx($image);
		      												$imageHeight = imagesy($image) * $ratio;
		      											}
													}
													elseif ((empty($imageWidth) || $imageWidth=="" || $imageWidth==0) && (empty($imageHeight) || $imageHeight=="" || $imageHeight==0)){
														$aContext = array('http' => array('request_fulluri' => True));
														$cxContext = stream_context_create($aContext);
														if(strstr($pic,"?"))
															$pic=substr($pic,0,strpos($pic,"?"));
														if(strlen($pic)>0){
															file_put_contents(JPATH_SITE."/images/rss2content/image.jpg", file_get_contents($pic, False, $cxContext));
															$image_info = getimagesize(JPATH_SITE."/images/rss2content/image.jpg");
		      												$image_type = $image_info[2];
		      												if( $image_type == IMAGETYPE_JPEG ) {
		         												$image = imagecreatefromjpeg(JPATH_SITE."/images/rss2content/image.jpg");
		      												} elseif( $image_type == IMAGETYPE_GIF ) {
														        $image = imagecreatefromgif(JPATH_SITE."/images/rss2content/image.jpg");
														    } elseif( $image_type == IMAGETYPE_PNG ) {
														        $image = imagecreatefrompng(JPATH_SITE."/images/rss2content/image.jpg");
														    }
														    unlink(JPATH_SITE."/images/rss2content/image.jpg");
															$imageHeight = imagesy($image);
															$imageWidth=imagesx($image);
														}
													}
													$te='<img src="'.$pic.'"  alt="'.$imageAlt.'" class="'.$imageClass.'" hspace="'.$imageHspace.'" vspace="'.$imageVspace.'" align="'.$imageAlign.'" border="'.$imageBorder;					
													if(strlen($imageWidth)>0){
														$te.=' width="'.$imageWidth.'"';
													}
													if(strlen($imageHeight)>0){
														$te.=' height="'.$imageHeight.'"';
													}
													$te.='">';
													
												}
												$desc=str_replace($img_tag,$te,$desc);
												//$desc=str_replace($pic,$src,$desc);
											}										
										}
									}
								}
								
								$temp=strip_tags($desc);
								$temps=explode(' ',$temp);									
								$texts = explode( ' ', $desc );
								$count = count( $temps );
								
								if ( $count > $rssitemdesc_words ) {
									$desc = '';
									$j=0;
									while(strip_tags($texts[$j])!=$temps[$rssitemdesc_words] && $j<count($texts)){
										$desc .= ' '. $texts[$j];
										$j++;										
									}
								
									rtrim($desc);
									ltrim($desc);
									$rest='';
									
									if($rssitemwords>0){	
										while(strip_tags($texts[$j])!=$temps[$rssitemdesc_words+$rssitemwords] && $j<count($texts)){
											$rest.=' '. $texts[$j];
											$j++;
										}
									}
									else if($rssitemwords==0){
										for($k=$j;$k<count($texts);$k++){
											$rest.=' '. $texts[$k];										
										}
									}
									rtrim($rest);
									ltrim($rest);
									
									$rest.='...<a href="'.$rssitemlink.'" '.$nofollow.' target="_blank">'.$readmoreText.'</a>';
								}
								else{
									$rest.='...<a href="'.$rssitemlink.'" '.$nofollow.' target="_blank">'.$readmoreText.'</a>';	
								}
							}
							
							
						}
						
						if($enclosure=$currItem->get_enclosure())
						{
							$pic='';
							$newName='';
													
							if($this->downloadYesNo($enclosure->get_link())){											
												$imageWidth=$imageWidthTemp;
												$imageHeight=$imageHeightTemp;
												if($downloadImage==1){
													$newName=$this->downloadPictures($enclosure->get_link(),JPATH_SITE);
													$newName=str_replace("%","",$newName);
													if((empty($imageWidth) || $imageWidth=="" || $imageWidth==0) && (!empty($imageHeight) || $imageHeight!="" || $imageHeight!=0)){
														$image_info = getimagesize(JPATH_SITE.'/images/rss2content/'.$newName);
	      												$image_type = $image_info[2];
	      												if( $image_type == IMAGETYPE_JPEG ) {
	         												$image = imagecreatefromjpeg(JPATH_SITE.'/images/rss2content/'.$newName);
	      												} elseif( $image_type == IMAGETYPE_GIF ) {
													        $image = imagecreatefromgif(JPATH_SITE.'/images/rss2content/'.$newName);
													    } elseif( $image_type == IMAGETYPE_PNG ) {
													        $image = imagecreatefrompng(JPATH_SITE.'/images/rss2content/'.$newName);
													    }
													    
														$ratio = $imageHeight/imagesy($image);
	      												$imageWidth = imagesx($image) * $ratio;
	      												
													}
													elseif((!empty($imageWidth) || $imageWidth!="" || $imageWidth!=0) && (empty($imageHeight) || $imageHeight=="" || $imageHeight==0)){
														$image_info = getimagesize(JPATH_SITE.'/images/rss2content/'.$newName);
	      												$image_type = $image_info[2];
	      												if( $image_type == IMAGETYPE_JPEG ) {
	         												$image = imagecreatefromjpeg(JPATH_SITE.'/images/rss2content/'.$newName);
	      												} elseif( $image_type == IMAGETYPE_GIF ) {
													        $image = imagecreatefromgif(JPATH_SITE.'/images/rss2content/'.$newName);
													    } elseif( $image_type == IMAGETYPE_PNG ) {
													        $image = imagecreatefrompng(JPATH_SITE.'/images/rss2content/'.$newName);
													    }
													    
														$ratio = $imageWidth/imagesx($image);
	      												$imageHeight = imagesy($image) * $ratio;
													}
													elseif((empty($imageWidth) || $imageWidth=="" || $imageWidth==0) && (empty($imageHeight) || $imageHeight=="" || $imageHeight==0)){
														$image_info = getimagesize(JPATH_SITE.'/images/rss2content/'.$newName);
	      												$image_type = $image_info[2];
	      												if( $image_type == IMAGETYPE_JPEG ) {
	         												$image = imagecreatefromjpeg(JPATH_SITE.'/images/rss2content/'.$newName);
	      												} elseif( $image_type == IMAGETYPE_GIF ) {
													        $image = imagecreatefromgif(JPATH_SITE.'/images/rss2content/'.$newName);
													    } elseif( $image_type == IMAGETYPE_PNG ) {
													        $image = imagecreatefrompng(JPATH_SITE.'/images/rss2content/'.$newName);
													    }
													    $imageWidth=imagesx($image);
														$imageHeight = imagesy($image);
													}
													
													$te='<img src="images/rss2content/'.$newName.'" hspace="'.$imageHspace.'"';
													if(strlen($imageHeight)>0)
														$te.=' height="'.$imageHeight.'"';
													if(strlen($imageWidth)>0)
														$te.=' width="'.$imageWidth.'"';
													
													$te.=' alt="'.$imageAlt.'" class="'.$imageClass.'" vspace="'.$imageVspace.'" align="'.$imageAlign.'" border="'.$imageBorder.'">';
												}
												else{
													$pic=$enclosure->get_link();
													if((empty($imageWidth) || $imageWidth=="" || $imageWidth==0) && (!empty($imageHeight) || $imageHeight!="" || $imageHeight!=0)){
														$aContext = array('http' => array('request_fulluri' => True));
														$cxContext = stream_context_create($aContext);
														if(strstr($pic,"?"))
															$pic=substr($pic,0,strpos($pic,"?"));
														if(strlen($pic)>0){
															file_put_contents(JPATH_SITE."/images/rss2content/image.jpg", file_get_contents($pic, False, $cxContext));
															$image_info = getimagesize(JPATH_SITE."/images/rss2content/image.jpg");
		      												$image_type = $image_info[2];
		      												if( $image_type == IMAGETYPE_JPEG ) {
		         												$image = imagecreatefromjpeg(JPATH_SITE."/images/rss2content/image.jpg");
		      												} elseif( $image_type == IMAGETYPE_GIF ) {
														        $image = imagecreatefromgif(JPATH_SITE."/images/rss2content/image.jpg");
														    } elseif( $image_type == IMAGETYPE_PNG ) {
														        $image = imagecreatefrompng(JPATH_SITE."/images/rss2content/image.jpg");
														    }
														    unlink(JPATH_SITE."/images/rss2content/image.jpg");
															$ratio = $imageHeight/imagesy($image);
		      												$imageWidth = imagesx($image) * $ratio;
														}      												
													}
													elseif ((!empty($imageWidth) || $imageWidth!="" || $imageWidth!=0) && (empty($imageHeight) || $imageHeight=="" || $imageHeight==0)){
														$aContext = array('http' => array('request_fulluri' => True));
														$cxContext = stream_context_create($aContext);
														if(strstr($pic,"?"))
															$pic=substr($pic,0,strpos($pic,"?"));
														if(strlen($pic)>0){
															file_put_contents(JPATH_SITE."/images/rss2content/image.jpg", file_get_contents($pic, False, $cxContext));
															$image_info = getimagesize(JPATH_SITE."/images/rss2content/image.jpg");
		      												$image_type = $image_info[2];
		      												if( $image_type == IMAGETYPE_JPEG ) {
		         												$image = imagecreatefromjpeg(JPATH_SITE."/images/rss2content/image.jpg");
		      												} elseif( $image_type == IMAGETYPE_GIF ) {
														        $image = imagecreatefromgif(JPATH_SITE."/images/rss2content/image.jpg");
														    } elseif( $image_type == IMAGETYPE_PNG ) {
														        $image = imagecreatefrompng(JPATH_SITE."/images/rss2content/image.jpg");
														    }
														    unlink(JPATH_SITE."/images/rss2content/image.jpg");
															$ratio = $imageWidth/imagesx($image);
		      												$imageHeight = imagesy($image) * $ratio;
		      											}
													}
													elseif ((empty($imageWidth) || $imageWidth=="" || $imageWidth==0) && (empty($imageHeight) || $imageHeight=="" || $imageHeight==0)){
														$aContext = array('http' => array('request_fulluri' => True));
														$cxContext = stream_context_create($aContext);
														if(strstr($pic,"?"))
															$pic=substr($pic,0,strpos($pic,"?"));
														if(strlen($pic)>0){
															file_put_contents(JPATH_SITE."/images/rss2content/image.jpg", file_get_contents($pic, False, $cxContext));
															$image_info = getimagesize(JPATH_SITE."/images/rss2content/image.jpg");
		      												$image_type = $image_info[2];
		      												if( $image_type == IMAGETYPE_JPEG ) {
		         												$image = imagecreatefromjpeg(JPATH_SITE."/images/rss2content/image.jpg");
		      												} elseif( $image_type == IMAGETYPE_GIF ) {
														        $image = imagecreatefromgif(JPATH_SITE."/images/rss2content/image.jpg");
														    } elseif( $image_type == IMAGETYPE_PNG ) {
														        $image = imagecreatefrompng(JPATH_SITE."/images/rss2content/image.jpg");
														    }
														    unlink(JPATH_SITE."/images/rss2content/image.jpg");
															$imageHeight = imagesy($image);
															$imageWidth=imagesx($image);
														}
													}
													$te='<img src="'.$pic.'"  alt="'.$imageAlt.'" class="'.$imageClass.'" hspace="'.$imageHspace.'" vspace="'.$imageVspace.'" align="'.$imageAlign.'" border="'.$imageBorder;					
													if(strlen($imageWidth)>0){
														$te.=' width="'.$imageWidth.'"';
													}
													if(strlen($imageHeight)>0){
														$te.=' height="'.$imageHeight.'"';
													}
													$te.='">';
												}
												$intro_text.=$te;	
											}
						}
						
						if ( $rssitemdesc ){
							$intro_text.='<div align="justify">'.$desc.'</div>';
						}
						
						
						
						$ima=false;
						foreach($t as $value){
							if(in_array(strtoupper($value),$filters))
								$ima=true;
						}
						foreach($texts as $value){
							if(in_array(strtoupper($value),$filters))
								$ima=true;
						}
						
						$upis=false;
						if($filter && $ima){
							$upis=true;
						}
						elseif ($filter && !$ima){
							$upis=false;
						}
						else{
							$upis=true;
						}
						if($htmlTag==1){
							$title_alias=strip_tags($title_alias,'<strong><div><br><a><img>');
							$alias=strip_tags($alias,'<strong><div><br><a><img>');
							$intro_text=strip_tags($intro_text,'<strong><div><br><a><img>');
							$rest=strip_tags($rest,'<strong><div><br><a><img>');
						}
						
						
						$rest='<div align="justify">'.$rest."</div><br>".$textAfter;
						
						$db->setQuery("SELECT * FROM #__content WHERE title_alias='".$title_alias."'");
						
						if(count($db->loadObjectList())==0 && $upis){
							
							if($serverTime){
								$datum=date("Y-m-d H:i:s",mktime(date("H")+$timeOffset-2,date("i"),date("s"),date("m"),date("d"),date("Y")));
								$datum1=date("Y-m-d H:i:s",mktime(date("H")+$timeOffset,date("i"),date("s"),date("m"),date("d"),date("Y")));
							}
							else{
								$datumx=date_format(date_create($currItem->get_date()),"Y-m-d H:i:s");
								$datum=$datumx;
								$datum1=$datumx;
							//	$datum=$this->dodaj_Offset($datumx,$timeOffset);
							//	$datum1=$this->dodaj_Offset($datumx,$timeOffset);
							}
							$content->id=null;
							$content->title=html_entity_decode($item_title,ENT_QUOTES,'UTF-8');
							$content->alias=$alias;
							$content->title_alias=$title_alias;
							$content->state=$autoPublished;
							$content->sectionid=$row->sectionid;
							$content->mask=0;
							$content->catid=$row->categoryid;
							$content->created=$datum1;
							$content->created_by=$row->author;
							$content->publish_up=$datum;
							$content->attribs=$x;
							$content->version=1;
							$content->ordering=$ordering;
							$content->metadesc=$desc;
							$content->access=0;
							
							if($fullTextIntro==0){
								$content->introtext=html_entity_decode($intro_text.$rest,ENT_QUOTES,'UTF-8');
								
						//		$db->setQuery("INSERT INTO #__content VALUES (NULL,'".$item_title."','".$alias."','".$title_alias."','".$intro_text.$rest."','','1','".$row->sectionid."',0,'".$row->categoryid."','".$datum1."','62','','','','','','".$datum."','','','','".$x."','1','','".$ordering."','','".$desc."','0','','')");
							}
							else{
								$content->introtext=html_entity_decode($intro_text,ENT_QUOTES,'UTF-8');
								$content->fulltext=html_entity_decode($rest,ENT_QUOTES,'UTF-8');
						//		$db->setQuery("INSERT INTO #__content VALUES (NULL,'".$item_title."','".$alias."','".$title_alias."','".$intro_text."','".$rest."','1','".$row->sectionid."',0,'".$row->categoryid."','".$datum1."','62','','','','','','".$datum."','','','','".$x."','1','','".$ordering."','','".$desc."','0','','')");
							}
							
							
							if (!$content->store()) {
								JError::raiseWarning( 500, $db->getError());
							}
							else{
								$downloadedIndex++;
								
								$numberOfRss++;
								$articles->articleId=$this->getLastId();
								$articles->linkId=$row->id;
								$articles->lastUpdate=date('Y-m-d H:i:s');
								$articles->store();
								//START TWITTER PART
								if(strlen($twetter_username)>0 && strlen($twetter_password)>0)
								{
									$address="";
									$db->setQuery("SELECT * FROM #__content WHERE title_alias='".$title_alias."'");
									$addr=$db->loadObjectList();
									$add=$addr[0];
									require_once(JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');				
									$path = ContentHelperRoute::getArticleRoute($add->id);
									
									$servername = NULL;
									$tmp_servername = JURI::base();
									
									$seen_slash = false;
									for($p=strlen($tmp_servername)-2; $p>=0; $p--) //minus 2 because of "0" and "cut off of last "/"
									{
										if($seen_slash==true)
											$servername=$tmp_servername[$p].$servername;
				
										if($tmp_servername[$p]=='/' && $seen_slash==false)
											$seen_slash = true;
									}
				
									$address = $servername.'/'.$path;
									$this->_send_twitter($twetter_username, $twetter_password, $this->_tinyURL($address), $title_alias,$twetter_attach);
									$twitteredIndex++;
								//END TWITTER PART
								}
							}
							$ordering++;
							if(in_array($row->categoryid,$categories) && $frontPage){
								$db->setQuery("SELECT * FROM #__content WHERE title_alias='".$title_alias."'");
								$datas=$db->loadObjectList();
								
								if(count($datas)>0){
									$data=$datas[0];
									$db->setQuery("INSERT INTO #__content_frontpage VALUES ('".$data->id."','".$ordering."')");
									$db->query();
									
								}
							
							}	
						}				
					}
				} //end item quantity check if statement
				$downloaded[$successIndex]=$downloadedIndex;
				$twittered[$successIndex]=$twitteredIndex;
				$successIndex++;
			}
		}
		if($downloadImage==1){
			$handle=opendir(JPATH_SITE.'/images/rocket/');
			while(!false==($file=readdir($handle))){
				if ($file != "." && $file != "..") {
            				unlink(JPATH_SITE.'/images/rocket/'.$file);
        			}
			}	
			
			$db->setQuery("SELECT * FROM #__rss2content_config");
			$datas=$db->loadObjectList();
			$data=$datas[0];
						
		
			$db->setQuery("SELECT * FROM #__content WHERE (INSTR(introtext,'<img')>0 OR INSTR(#__content.fulltext,'<img')>0) AND catid='".$data->modulSection."' ORDER BY created DESC LIMIT ".$data->imageNumber);
			$rows=$db->loadObjectList();
			
			for($k=0;$k<count($rows);$k++){
				$row=$rows[$k];			
				$slika='';
				$newFile='';
				if(strstr($row->introtext,'<img')){
					$slika='';
								preg_match_all('/<img[^>]+>/i',$row->introtext, $result); 
								foreach($result as $result1)
								{					
									foreach( $result1 as $img_tag)
									{
			   							preg_match('/(src)=("[^"]*")/i',$img_tag, $img);
			   							$pic=str_replace('"','',$img[2]);
										if(strstr($pic,"?"))
											$pic=substr($pic,0,strpos($pic,"?"));
										$fname=explode("/",$pic);
										if($fname)
										{
																		
											if(strlen($fname[count($fname)-1])>0){
												$slika=$fname[count($fname)-1];
											}
										}
									}
								}
								if(file_exists(JPATH_SITE.'/images/rss2content/'.$slika)){
									copy(JPATH_SITE.'/images/rss2content/'.$slika,JPATH_SITE.'/images/rocket/'.$slika);
									$newFile=substr($slika,0,strrpos($slika,'.')).'.txt';
									$fp=fopen(JPATH_SITE.'/images/rocket/'.$newFile,'w');
									fwrite($fp, $row->title." \n");
					
									$li='/index.php?option=com_content&view=article&id='.$row->id;
									fwrite($fp, $li." \n");
						
									$t=strip_tags($row->introtext);
									$niz=explode(' ',$t);
									$t='';
									for($j=0;$j<$data->wordNumber;$j++){
										$t.=' '.$niz[$j];
									}
									$t=trim($t);
									fwrite($fp,$t);
									fclose($fp);
								}
				}
				else if(strpos($row->fulltext,'<img')){
					$slika='';
								preg_match_all('/<img[^>]+>/i',$row->fulltext, $result); 
								foreach($result as $result1)
								{					
									foreach( $result1 as $img_tag)
									{
			   							preg_match('/(src)=("[^"]*")/i',$img_tag, $img);
			   							$pic=str_replace('"','',$img[2]);
										if(strstr($pic,"?"))
											$pic=substr($pic,0,strpos($pic,"?"));
										$fname=explode("/",$pic);
										if($fname)
										{
											if(strlen($fname[count($fname)-1])>0){
												$slika=$fname[count($fname)-1];
											}
										}
									}
								}
								if(file_exists(JPATH_SITE.'/images/rss2content/'.$slika)){
									copy(JPATH_SITE.'/images/rss2content/'.$slika,JPATH_SITE.'/images/rocket/'.$slika);
									$newFile=substr($slika,0,strrpos($slika,'.')).'.txt';
									$fp=fopen(JPATH_SITE.'/images/rocket/'.$newFile,'w');
									fwrite($fp, $row->title." \n");
						
									$li='/index.php?option=com_content&view=article&id='.$row->id;
									fwrite($fp, $li." \n");
									
									$t=strip_tags($row->introtext);
									$niz=explode(' ',$t);
									$t='';
									for($j=0;$j<$data->wordNumber;$j++){
										$t.=' '.$niz[$j];
									}
									$t=trim($t);
									fwrite($fp,$t);
									fclose($fp);
								}
				}
			}
		}
		//return the feed data structure for the template	
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		
		HTML_Rss2Content::manualLoadRss($option,$feeds,$downloaded,$twittered);
	}
	
	function manualLoadRss(){
		$this->getFeed();
	}
	
	function archiveFeed($archive){
	    if($archive>0){
		$db	=& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__rss2content");
		$rows = $db->loadObjectList();
		$section=array();
		$category=array();
		
		if(count($rows)>0){
			for ($j=0;$j<count($rows);$j++){
				$row=$rows[$j];
				if(!in_array($row->categoryid,$category))
					array_push($category,$row->categoryid);
				if(!in_array($row->sectionid,$section))
					array_push($section,$row->sectionid);
			}
		}
		
		$cat="(";
		while (list(, $val) = each($category)) {
    		$cat.=$val.",";
		}
		$cat.="0)";
		
		$sec="(";
		while (list(, $val) = each($section)) {
    		$sec.=$val.",";
		}
		$sec.="0)";

		$db->setQuery("SELECT id FROM #__content WHERE curdate() > DATE(DATE_ADD(created, INTERVAL ".$archive." DAY)) and catid in ".$cat." and sectionid in ".$sec." and id in (SELECT articleId from #__rss2content_articles)");
		$datas=$db->loadObjectList();
		$con="(";
		for($j=0;$j<count($datas);$j++){
			$data=$datas[$j];
			$con.=$data->id.",";
		}
		$con.="0)";
		
		$db->setQuery("DELETE FROM #__content_frontpage WHERE content_id in ".$con);
		if (!$db->query()) {
			JError::raiseWarning( 500, $db->getError());
		}			
		
		$db->setQuery("UPDATE #__content SET state=-1 WHERE curdate() > DATE(DATE_ADD(created, INTERVAL ".$archive." DAY)) and catid in ".$cat." and sectionid in ".$sec);
		if (!$db->query()) {
			JError::raiseWarning( 500, $db->getError());
		}	
	    }	
	}
	
	function deleteFeeds($deleteTime){
		if($deleteTime>0){
			$db	=& JFactory::getDBO();
			$db->setQuery("SELECT * FROM #__rss2content");
			$rows = $db->loadObjectList();
			$section=array();
			$category=array();
		
			if(count($rows)>0){
				for ($j=0;$j<count($rows);$j++){
					$row=$rows[$j];
					if(!in_array($row->categoryid,$category))
						array_push($category,$row->categoryid);
					if(!in_array($row->sectionid,$section))
						array_push($section,$row->sectionid);
				}
			}
		
			$cat="(";
			while (list(, $val) = each($category)) {
    			$cat.=$val.",";
			}
			$cat.="0)";
		
			$sec="(";
			while (list(, $val) = each($section)) {
    			$sec.=$val.",";
			}
			$sec.="0)";
			
			$db->setQuery("SELECT id FROM #__content WHERE curdate() > DATE(DATE_ADD(created, INTERVAL ".$deleteTime." DAY)) and catid in ".$cat." and sectionid in ".$sec." and id in (SELECT articleId from #__rss2content_articles)");
			$datas=$db->loadObjectList();
			$con="(";
			for($j=0;$j<count($datas);$j++){
				$data=$datas[$j];
				$con.=$data->id.",";
				$db->setQuery("SELECT * FROM #__content WHERE id='".$data->id."'");
				$slike=$db->loadObjectList();
				$slika=$slike[0];
				$this->deletePictures($slika->introtext,$slika->fulltext);
			}
			$con.="0)";
			
			$db->setQuery("DELETE FROM #__content_frontpage WHERE content_id in ".$con);
			if (!$db->query()) {
				JError::raiseWarning( 500, $db->getError());
			}			
		
			$db->setQuery("DELETE FROM #__content WHERE curdate() > DATE(DATE_ADD(created, INTERVAL ".$deleteTime." DAY)) and catid in ".$cat." and sectionid in ".$sec);
			if (!$db->query()) {
				JError::raiseWarning( 500, $db->getError());
			}
			else{
			//	$db->setQuery("DELETE FROM ".$prefix."redirection WHERE dateadd > '0000-00-00' and `newurl` = ''");
			//	$db->query();
			//	if (file_exists(JPATH_ROOT.'/components/com_sh404sef/cache/shCacheContent.php'))
			//		unlink(JPATH_ROOT.'/components/com_sh404sef/cache/shCacheContent.php');
			}
			$db->setQuery("DELETE FROM #__rss2content_articles WHERE articleID in ".$con);
			if(!$db->query()){
				JError::raiseWarning( 500, $db->getError());
			}
		}
	}
	
	function downloadPictures($slika,$path){
 
		$server_dir = $path."/images/rss2content/";
		$imageurl = $slika;
		
		if(strpos($imageurl,'?'))
			$imageurl=substr($imageurl,0,strpos($imageurl,'?'));
		$fname=explode("/",$imageurl);
   	 	
		if($fname)
    	{
			foreach($fname as $f)
			{
				$thefile=$f;
			}
		}
		
		if ($thefile!="") 
		{
			$thefile=str_replace("%","",$thefile);
			//if(strpos($slika,'www.itsvet.com'))
			//	$thefile=$this->newImageName($thefile);
			$thefile='Rss2Content_'.date("dmYHisu").'_'.$thefile;
			$newFile = $server_dir . $thefile;                        
			if (!$this->download($slika, $newFile)) 
			{
				$messages.="|". "Please check site settings in admin panel and set proper value for server local path.";
			}
		}
		return $thefile;
	}

	function downloadLogo($slika,$path){
		$server_dir = $path."/images/rss2content/";
		$imageurl = $slika;
		if(strpos($imageurl,'?'))
			$imageurl=substr($imageurl,0,strpos($imageurl,'?'));
		$fname=explode("/",$imageurl);
   	 	
		if($fname)
    	{
			foreach($fname as $f)
			{
				$thefile=$f;
			}
		}
		
		if ($thefile!="") 
		{
			$thefile=str_replace("%","",$thefile);
			
			$thefile='Rss2Content_logo_'.$thefile;
			$newFile = $server_dir . $thefile;                        
			if (!$this->download($slika, $newFile)) 
			{
				$messages.="|". "Please check site settings in admin panel and set proper value for server local path.";
			}
		}
		return $thefile;
	}

	function download ($file_source, $file_target)
	{
		$file_source = str_replace(' ', '%20', html_entity_decode($file_source));
		if (file_exists($file_target)) { chmod($file_target, 0777); }         
		if (($rh = fopen($file_source, 'rb')) === FALSE) { return false; }
		if (($wh = fopen($file_target, 'wb')) === FALSE) { return false; } 
		while (!feof($rh))
		{
			if (fwrite($wh, fread($rh, 1024)) === FALSE) { fclose($rh); fclose($wh); return false; }
		}
		fclose($rh);
		fclose($wh);
		return true;
	}
	
	function getSelectedImages(){
		$db	=& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__rss2content_config");
		$datas=$db->loadObjectList();
		$data=$datas[0];
		
		$db->setQuery("SELECT * FROM #__content WHERE (INSTR(introtext,'<img')>0 OR INSTR(#__content.fulltext,'<img')>0) AND catid='".$data->modulSection."' ORDER BY created DESC LIMIT ".$data->imageNumber);
		$rows = $db->loadObjectList();
		for($i=0;$i<count($rows);$i++){
			$row=$rows[$i];
			$slika='';
			$newFile='';
			if(strpos($row->introtext,'<img')){
				preg_match_all('/<img[^>]+>/i',$row->introtext, $result); 
				foreach($result as $result1)
				{					
					foreach( $result1 as $img_tag)
					{
   						preg_match('/(src)=("[^"]*")/i',$img_tag, $img);
   						$pic=str_replace('"','',$img[2]);
					}
				}
				$fname=explode("/",$pic);
   	 			if($fname)
    			{
					foreach($fname as $f)
					{
						$slika=$f;
					}	
				}
				copy(JPATH_SITE.'/images/rss2content/'.$slika,JPATH_SITE.'/images/rocket/'.$slika);
				$newFile=substr($slika,0,strrpos($slika,'.')).'.txt';
				$fp=fopen(JPATH_SITE.'/images/rocket/'.$newFile,'w');
				fwrite($fp, $row->title." \n");
				$db->setQuery("SELECT * FROM #__categories WHERE id='".$row->catid."'");
				$imena=$db->loadObjectList();
				$ime=$imena[0];
				fwrite($fp, "/".$ime->title."/".str_replace(" ","-",$row->title_alias).".html \n");
				$t=strip_tags($row->introtext);
				$niz=explode(' ',$t);
				$t='';
				for($j=0;$j<$data->wordNumber;$j++){
					$t.=' '.$niz[$j];
				}
				$t=trim($t);
				fwrite($fp,$t);
				fclose($fp);
			}
			else if(strpos($row->fulltext,'<img')){
				preg_match_all('/<img[^>]+>/i',$row->fulltext, $result); 
				foreach($result as $result1)
				{					
					foreach( $result1 as $img_tag)
					{
   						preg_match('/(src)=("[^"]*")/i',$img_tag, $img);
   						$pic=str_replace('"','',$img[2]);
					}
				}
				$fname=explode("/",$pic);
   	 			if($fname)
    			{
					foreach($fname as $f)
					{
						$slika=$f;
					}	
				}
				copy(JPATH_SITE.'/images/rss2content/'.$slika,JPATH_SITE.'/images/rocket/'.$slika);
				$newFile=substr($slika,0,strrpos($slika,'.')).'.txt';
				$fp=fopen(JPATH_SITE.'/images/rocket/'.$newFile,'w');
				fwrite($fp, $row->title." \n");
				$db->setQuery("SELECT * FROM #__categories WHERE id='".$row->catid."'");
				$imena=$db->loadObjectList();
				$ime=$imena[0];
				fwrite($fp, "/".$ime->title."/".str_replace(" ","-",$row->title_alias).".html \n");
				$t=strip_tags($row->introtext);
				$niz=explode(' ',$t);
				$t='';
				for($j=0;$j<$data->wordNumber;$j++){
					$t.=' '.$niz[$j];
				}
				$t=trim($t);
				fwrite($fp,$t);
				fclose($fp);
			}
		}
	}
	function newImageName($fname) {
    	$timestamp = time();
    	$new_image_file_ext = substr($fname, strlen($fname) - 3, strlen($fname));
    	if ($new_image_file_ext == "peg") {
        	$ext = ".jpg";
    	} else {
			$ext = "." . $new_image_file_ext;
   	 	}
    	$newfilename = $this->randString() . substr($timestamp, strlen(timestamp) - 4, strlen(timestamp)) . $ext;
    	return $newfilename;
	}

	function randString() {
    	$newstring="";
    	while(strlen($newstring) < 3) {
        	$randnum = mt_rand(0,61);
        	if ($randnum < 10) {
            	$newstring .= chr($randnum + 48);
        	} elseif ($randnum < 36) {
            	$newstring .= chr($randnum + 55);
        	} else {
            	$newstring .= chr($randnum + 61);
        	}
    	}
    	return $newstring;
	}

	function deletePictures($introText,$fullText){
		if(strpos($introText,'<img')){
			preg_match_all('/<img[^>]+>/i',$introText, $result); 
			foreach($result as $result1)
			{					
				foreach( $result1 as $img_tag)
				{
   					preg_match('/(src)=("[^"]*")/i',$img_tag, $img);
   					$pic=str_replace('"','',$img[2]);
   					
					if(file_exists(JPATH_ROOT."/".$pic) && is_file(JPATH_ROOT."/".$pic)){
						unlink(JPATH_ROOT."/".$pic);
   					}
				}
			}
		}
		if(strpos($fullText,'<img')){
			preg_match_all('/<img[^>]+>/i',$fullText, $result); 
			foreach($result as $result1)
			{					
				foreach( $result1 as $img_tag)
				{
   					preg_match('/(src)=("[^"]*")/i',$img_tag, $img);
   					$pic=str_replace('"','',$img[2]);
   					
   					if(file_exists(JPATH_ROOT."/".$pic) && is_file(JPATH_ROOT."/".$pic)){
   						unlink(JPATH_ROOT."/".$pic);
   					}
				}
			}
		}
	}
	
	function showCronTask(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$db	=& JFactory::getDBO();
		
		$db->setQuery("SELECT * FROM #__cron_task");
		$datas=$db->loadObjectList();
		$data=$datas[0];
		$query = "SELECT template"
			   . "\n FROM #__templates_menu"
			   . "\n WHERE client_id = 0"
			   . "\n AND menuid = 0"
			   ;
	    $db->setQuery( $query );
	
	    $cur_template = $db->loadResult();
	
	    $tfile = JPATH_SITE."/templates/".$cur_template."/index.php";
	          
	    $file = file_get_contents($tfile);
		$incl_code="from_template = 1;@include('components/com_rss2content/crontask.php');";
	
	    if(strstr($file, $incl_code))
	     $_CONFIG['iscron'] = true;
	    else
	     $_CONFIG['iscron'] = false;
	     
		HTML_Rss2Content::showCronTask($option,$data,$_CONFIG);
	}
	
	function saveCronTask(){
		$option = JRequest::getCmd('option');
		require_once(JPATH_COMPONENT.DS.'admin.rss2content.html.php');
		$db	=& JFactory::getDBO();
		
		   
	    $query = "SELECT template"
			   . "\n FROM #__templates_menu"
			   . "\n WHERE client_id = 0"
			   . "\n AND menuid = 0"
			   ;
	    $db->setQuery( $query );
	
	    $cur_template = $db->loadResult();
	
	    $tfile = JPATH_SITE."/templates/".$cur_template."/index.php";
	          
	    $file = file_get_contents($tfile);
		$incl_code="\n<"."?php $"."from_template = 1;@include('components/com_rss2content/crontask.php'); ?".">\n";
	
	   	
	    if(isset($_REQUEST['crond2'])){
	        ####### ADD TEMPLATE CRON CODE
	        if($fp = fopen($tfile, 'w')){
	          fwrite($fp, $file.$incl_code);
	          fclose($fp);
	          $msg = "File $tfile successfully updated, cron is now running!";
	           $this->setRedirect( 'index2.php?option='.$option."&act=cron" , $msg);
	        }
	        else{
	          $msg = "Could not open $tfile for writing, please add this code manually:<br/>
	          <b>$incl_code</b>";
	          $this->setRedirect( 'index2.php?option='.$option."&act=cron" , $msg);
	        }
	    }
	    elseif(isset($_REQUEST['crond1'])){
	        ####### REMOVE TEMPLATE CRON CODE
	        if($fp = fopen($tfile, 'w')){
	          $file = str_replace($incl_code, "", $file);
	          fwrite($fp, $file);
	          fclose($fp);
	          $msg = "File $tfile successfully updated, cron is now removed!";
	         $this->setRedirect( 'index2.php?option='.$option."&act=cron" , $msg);
	        }
	        else{
	          $msg = "Could not open $tfile for writing, please remove this code manually:<br/>
	          <b>$incl_code</b>";
	          $this->setRedirect( 'index2.php?option='.$option."&act=cron" , $msg);
	        }
	    }
		elseif(isset($_REQUEST['saveCron'])){
		
			$db->setQuery("UPDATE #__cron_task SET  executeurl='".$_REQUEST['executeurl']."',
                                                   fetchwith='".$_REQUEST['fetchwith']."',  
                                                   storepath='".$_REQUEST['storepath']."',
                                                   storeas='".$_REQUEST['storeas']."',
                                                   savefull='".$_REQUEST['savefull']."',
                                                   chunksize='".$_REQUEST['chunksize']."',
                                                   timeperiod='".$_REQUEST['timeperiod']."' WHERE id=".$_REQUEST['id']);
                                                   
           
            if (!$db->query()) {
				JError::raiseWarning( 500, $db->getError());
			}
		    else{
			    $msg = "Tasks successfully registered!";
			    $this->setRedirect( 'index2.php?option='.$option."&act=cron" , $msg);
			}
		}
	}
	function _send_twitter($login, $pass, $tiny_address, $title,$twitter_attach)
	{
		global $mainframe;

		//connect & send section
		$host = 'twitter.com';
		$port = 80;

		/*
		  If user checked Twitter option in User Details, article
		  title will be send to his Twitter; nice one, yeah?
		*/
		$fp = fsockopen( $host, $port, $err_num, $err_msg, 10 );

		$account_data = base64_encode($login.':'.$pass);
		if(($login != NULL) && ($pass != NULL))
		{
			if($fp)
			{
				$attach = $twitter_attach;

				$twit = 'status='.$title;
				if($attach==1)
					$twit = $twit.' '.$tiny_address;

				$dlugosc = strlen($twit);
				if($dlugosc>147) //140=data+7=header
				{
					//cutting chars from title
					$title_shorted = substr($title, 0, strlen($title)-($dlugosc-147));

					$twit = 'status='.$title_shorted;
					if($attach==1)
						$twit = $twit.' '.$tiny_address;

					$dlugosc = strlen($twit);
				}

				fputs($fp, "POST /statuses/update.xml HTTP/1.1\n");
				fputs($fp, "Authorization: Basic $account_data\n");
				fputs($fp, "Host: $host\n");
				fputs($fp, "Content-type: application/x-www-form-urlencoded, charset=utf-8\n");
				fputs($fp, "Content-length: $dlugosc\n");
				fputs($fp, "Connection: close\n\n");
				fputs($fp, $twit);

				/* checking that status has been *really* updated */
				$buf = NULL;
				while(!feof($fp))
				{
					$buf .= fgets($fp,128);
				}
				fclose($fp);

				if(strpos($buf, '401 Unauthorized'))
					$mainframe->enqueueMessage("Seems like you filled in wrong username or password in Twitter Status Plugin configuration. Twitter status will be not updated", 'error');
				else
					$mainframe->enqueueMessage("Your Twitter status has been just updated ($login account)");
			}
		}
		else
		{
			if($login==NULL && $pass==NULL)
				$mainframe->enqueueMessage( JText::_("Did you forget to fill in configuration of Twitter Status Plugin? I can't update Twitter status without username and password ;)"), 'notice' );
			elseif($pass==NULL)
				$mainframe->enqueueMessage( JText::_($login."! did you forget to fill in configuration of Twitter Status Plugin? I can't update Twitter status without password ;)"), 'notice' );
			elseif($login==NULL)
				$mainframe->enqueueMessage( JText::_("Did you forget to fill in configuration of Twitter Status Plugin? I can't update Twitter status without username ;)"), 'notice' );
		}
	}

	function _tinyURL($address)
	{
		global $mainframe;

		/*
		  Warning! This function decide to create full or partial address
		  if u want to stick with uncompressed URL (without Tiny script)
		  uncomment line below
		*/
		$address = str_replace('&amp;', '&', $address);
		//$address = str_replace('&', '%26', $address);


		/* Short address to article */
		$tiny = fsockopen(gethostbyname("tinyurl.com"), 80);
		$com = "GET /api-create.php?url=$address HTTP/1.1\r\nHost: tinyurl.com:80\r\nConnection: close\r\n\r\n";
		fputs($tiny, $com);

		$cont = NULL;
		if(strlen($tiny)>0)
		{
			while(!feof($tiny))
			{
				$cont .= fread($tiny, 64);
			}
			fclose($tiny);
		}
		else
		{
			$mainframe->enqueueMessage("Connection timed out with TinyURL :( I could not update your Twitter", 'error');
			return;
		}
		return substr($cont,strpos($cont, "http://tinyurl.com/"),strrpos($cont,'0')-strpos($cont,"http://tinyurl.com/"));
	//	return substr($cont, strpos($cont, "http://tinyurl.com/"), 25);
	}
	
	function getLastId(){
		$db	=& JFactory::getDBO();
		$db->setQuery("SELECT * FROM #__content ORDER BY id desc LIMIT 1");
		$rows=$db->loadObjectList();
		if(count($rows)>0)
			return $rows[0]->id;
		else
			return 0;
	}
	
	function downloadYesNo($pictures){
		if(substr($pictures,-4)=='.jpg' or substr($pictures,-4)=='.png' or substr($pictures,-4)=='.gif' or substr($pictures,-4)=='.bmp' or substr($pictures,-5)=='.jpeg')
			return true;
		else
			return false;
	}
	
		function getReplacements($text)
	{
	    $shReplacements = array();
	    $items = explode(',', $text);
	    foreach ($items as $item) {
	      if (!empty($item)) {  // V 1.2.4.q better protection. Returns null array if empty
	        @list($src, $dst) = explode('|', trim($item));
	        $shReplacements[trim($src)] = trim($dst);
	      }
	    }
	
	    return $shReplacements;
  	}
	  
	function getStripCharList($text)
	{
	    return explode('|', $text);
  	}	
	
	function dodaj_Offset($orgDate,$offset){
	  $cd = strtotime($orgDate);
	  $retDAY = date('Y-m-d H:i:s', mktime(date('H',$cd)+$offset,date('i',$cd),date('s',$cd),date('m',$cd),date('d',$cd),date('Y',$cd)));
	  return $retDAY;
	} 
}


?>