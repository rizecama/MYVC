-- DROP TABLE IF EXISTS `#__rss2content`;
-- DROP TABLE IF EXISTS `#__rss2content_config`;
-- DROP TABLE IF EXISTS `#__rss2content_filter`;

CREATE TABLE IF NOT EXISTS `#__rss2content` (
	`id` int(10) NOT NULL auto_increment,
	`url` text NOT NULL,
	`author` text NOT NULL,
	`sectionid` int(10) NOT NULL,
	`categoryid` int(10) NOT NULL,
	`ordering` int(10) NOT NULL,
	`published` TINYINT(1) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `#__rss2content_filter` (
	`id` int(10) NOT NULL auto_increment,
	`filtertext` text NOT NULL,
	`sectionid` int(10) NOT NULL,
	`categoryid` int(10) NOT NULL,
	`published` TINYINT(1) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `#__rss2content_config` (
			  `id` int(10) NOT NULL auto_increment,
			  `rsstitle` tinyint(1) NOT NULL,
			  `rssdesc` tinyint(1) NOT NULL,
			  `rssimage` tinyint(1) NOT NULL,
			  `rssitems` text NOT NULL,
			  `rssitemtitle_words` text NOT NULL,
			  `rssitemdesc` tinyint(1) NOT NULL,
			  `rssitemdesc_words` text NOT NULL,
			  `rssitemdesc_images` tinyint(1) NOT NULL,
			  `link_target` tinyint(1) NOT NULL,
			  `rssitemwords` text NOT NULL,
			  `no_follow` tinyint(1) NOT NULL,
			  `filter` tinyint(1) NOT NULL,
			  `fullTextIntro` tinyint(1) NOT NULL,
			  `autoPublished` tinyint(1) NOT NULL,
			  `frontPage` tinyint(1) NOT NULL,
			  `sectionid` text NOT NULL,
			  `categoryid` text NOT NULL,
			  `readmoreText` text NOT NULL,
			  `feedsource` tinyint(1) NOT NULL,
			  `feedsourceText` text NOT NULL,
			  `archive` text NOT NULL,
			  `deleteTime` text NOT NULL,
			  `timeOffset` text NOT NULL,
			  `textAfter` text NOT NULL,
			  `htmlTag` tinyint(1) NOT NULL,
			  `imageNumber` text NOT NULL,
			  `wordNumber` text NOT NULL,
			  `modulSection` text NOT NULL,
			  `imageWidth` text NOT NULL,
			  `imageHeight` text NOT NULL,
			  `imageAlt` text NOT NULL,
			  `imageClass` text NOT NULL,
			  `imageHspace` text NOT NULL,
			  `imageVspace` text NOT NULL,
			  `imageAlign` text NOT NULL,
			  `imageBorder` text NOT NULL,
			  `downloadImage` tinyint(1) NOT NULL,
			  `feedImageWidth` text NOT NULL,
			  `feedImageHeight` text NOT NULL,
			  `twetter_username` text NOT NULL,
			  `twetter_password` text NOT NULL,
			  `twetter_sections` text NOT NULL,
			  `twetter_categories` text NOT NULL,
			  `twetter_attach` text NOT NULL,
			  `twetter_user_layer` text NOT NULL,
			  `aliasConnector` tinyint(1) NOT NULL,
			  `aliasConnectorText` text NOT NULL,
			  `replacements` text NOT NULL,
			  `strip` text NOT NULL,
			  `serverTime` tinyint(1) NOT NULL,
			   PRIMARY KEY  (`id`)
);


CREATE TABLE IF NOT EXISTS `#__cron_task` (
          `id` int(10) unsigned NOT NULL auto_increment,
          `executeurl` text NOT NULL,
          `fetchwith` text NOT NULL,
          `storepath` text NOT NULL,
          `storeas` text NOT NULL,
          `savefull` text NOT NULL,
          `chunksize` text NOT NULL,
          `timeperiod` text NOT NULL,
         PRIMARY KEY  (`id`)
) TYPE=MyISAM;

CREATE TABLE IF NOT EXISTS `#__rss2content_articles` (
		 `linkId` int(10) NOT NULL,
		 `articleId` int(10) NOT NULL,
		 `lastUpdate` datetime
);

-- INSERT INTO `#__rss2content_config` VALUES (NULL,'1','1','1','5','15','1','25','1','1','10','0','0','1','0','0','0','30','0','0','','0','4','12','','','','','','7','1','left','0',1,'','');