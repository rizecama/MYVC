<?php

/**
 * @package    Joomla
 * @subpackage Components
 * administrator/com_rss2content/admin.rss2content.html.php
 * @license    GNU/GPL
 * @copyright (C) 2009 rss2content.com
 * @author NenadT <nenadt@gmail.com>
 * @version $Id: rss2content.php,v 1.1 2009/07/22 Exp $
*/

defined('_JEXEC') or die();

class HTML_Rss2Content{
	
	
	function listRss($option,$rows){
		HTML_Rss2Content::listMenu();
		?>
		 	
				<form action="index2.php" method="post"  name="adminForm" id="adminForm" class="adminForm">
				<table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminlist">
				<THEAD>
				
                <th width="20"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($rows); ?>);" /></th> 
				<th width="5%" class="title">No.</th>
                <th width="40%" class="title"  id="naslov">Rss:</th>
				<th class="title">Author</th>
                <th class="title">Category</th>
                <th class="title">Section</th>
                <th class="title">Last update</th>
                <th width="5%" class="title">Published</th>
				</THEAD>
				<TBODY>
                <?php
				$db	=& JFactory::getDBO();
				$k = 0;
				for($i=0;$i<count($rows);$i++){
					$row=$rows[$i];
					$published = JHTML::_('grid.published', $row, $i );
                	$checked = JHTML::_('grid.id', $i, $row->id );
					$db->setQuery("SELECT * FROM #__sections WHERE id=".$row->sectionid);
					$sects=$db->loadObjectList();
					$sec=$sects[0];
					
					$db->setQuery("SELECT * FROM #__categories WHERE id=".$row->categoryid);
					$cats=$db->loadObjectList();
					$cat=$cats[0];
					
					$db->setQuery("SELECT * FROM #__users WHERE id=".$row->author);
					$auts=$db->loadObjectList();
					$aut=$auts[0];
					
					$db->setQuery("SELECT * FROM #__rss2content_articles WHERE linkId=".$row->id." order by lastUpdate desc LIMIT 1" );
					$lasts=$db->loadObjectList();
					$last=$lasts[0];
				?>
				<tr class="<?php echo 'rss$k'; ?>">
                	<td><?php echo $checked; ?></td>
					<td><?php echo ($i+1);?></td>
					<td><a href="<?php echo $row->url;?>" target="_blank"><?php echo $row->url;?></a></td>
                    <td><?php echo $aut->name;?></td>
					<td><?php echo $sec->title;?></td>
                    <td><?php echo $cat->title;?></td>
                    <td><?php echo $last->lastUpdate;?></td>
                    <td align="center">
					<?php
                    if ($row->published == "1") {
                        echo "<a href=\"javascript: void(0);\" onClick=\"return listItemTask('cb$i','unpublishAll')\"><img src=\"images/tick.png\" border=\"0\" /></a>";
                    } else {
                        echo "<a href=\"javascript: void(0);\" onClick=\"return listItemTask('cb$i','publishAll')\"><img src=\"images/publish_x.png\" border=\"0\" /></a>";
                    }
           ?>
                    </td>
                    <?php $k = 1 - $k; ?>
				</tr>
				
				<?php
				}
				?>
				</TBODY>
			</table>
			
			<input type="hidden" name="option" value="<?php echo $option; ?>" />
			<input type="hidden" name="task" value="" />
			<input type="hidden" name="boxchecked" value="0" />
			</form>
		<?php
	}
	
	function showConfiguration($option,$row,$sects){
		HTML_Rss2Content::configurationMenu();
		jimport('joomla.html.pane');
		$categories=array();
		$categories=explode(",",$row->categoryid);
		
		?>
    	<script language='javascript' type='text/javascript'>
			<!--
			function prikazi(){
				for (i=1;i<<?php $n=count($sects);$sect=$sects[$n-1];echo $sect->id+1;?>;i++){
					if(document.getElementById(i))
						document.getElementById(i).style.visibility="hidden";
				}
				
				if(document.getElementById('section').value==0){
					for (i=1;i<<?php $n=count($sects);$sect=$sects[$n-1];echo $sect->id+1;?>;i++){
						if(document.getElementById(i))
							document.getElementById(i).style.visibility="hidden";
					}
					
				}
				else{
					slika=document.getElementById('section').value; 
					document.getElementById(slika).style.visibility='visible';
				}
				
			}
			
			function hideAll(){
				document.getElementById("section").style.visibility='hidden';
				for (i=1;i<<?php $n=count($sects);$sect=$sects[$n-1];echo $sect->id+1;?>;i++){
						if(document.getElementById(i))
							document.getElementById(i).style.visibility="hidden";
					}
				
			}
			
			//-->
			</script>
			<style type="text/css">
<!--
.style2 {color: #CC3300}
.style3 {color: #000000}
.style4 {color: #999999}
.style6 {color: #000000; font-weight: bold; }
-->
            </style>
			
    	<form action="index2.php" method="post"  name="adminForm" id="adminForm" class="adminForm">
		<?php
        $tabs	=& JPane::getInstance('tabs');
		echo $tabs->startPane('rssconfiguration');
		echo $tabs->startPanel('Rss configuration', 'rssconfiguration-page');
		?>
        <table cellpadding="4" cellspacing="1" border="0" width="100%" class="adminlist">
        	
		<thead>
			  <tr><th WIDTH="1%" CLASS="title">&nbsp;</th>
				<th WIDTH="18%" CLASS="title">Name</th>
				<th WIDTH="19%" CLASS="title">Value</th>
				<th width="43%" CLASS="title">Description</th>
		        <th width="19%" CLASS="title">&nbsp;</th>
			  </tr>
        </thead>
			<tbody>
        	
            <tr>
              <td rowspan="4" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
              <td height="28" colspan="3" bgcolor="#CCCCCC"><span class="title"><img src="../components/com_rss2content/images/configheder.png" width="550" height="60" /></span><br />
                <span class="style3">Configure entered rss feeds, (what to collect, howto open links...)</span></td>
              <td rowspan="13" valign="top" bgcolor="#CCCCCC"><span class="title"><img src="../components/com_rss2content/images/logo.png" width="340" height="79" /></span></td>
            </tr>
            <tr>
              <td><span class="style6">Feed Title:</span></td>
              <td><span class="style3">
              <input type="radio" name="rsstitle" value="1" <?php if($row->rsstitle=="1") echo 'CHECKED="checked"'; ?>>
              &nbsp;Yes&nbsp;&nbsp;
              <input type="radio" name="rsstitle" value="0" <?php if($row->rsstitle=="0") echo 'CHECKED="checked"'; ?>>
              &nbsp;No</span></td>
        		<td><span class="style3"><strong>Collect Feed Title</strong></span><br />
  In  content item, Feed Title is displayed at the beginning of content, &nbsp;with link to Feed Source&nbsp; <strong><br />
                </strong></td>
   	          </tr>
            <tr>
              <td><span class="style6">Feed Description:</span></td>
              <td><span class="style3">
              <input type="radio" name="rssdesc" value="1" <?php if($row->rssdesc=="1") echo 'CHECKED="checked"'; ?>>
              &nbsp;Yes&nbsp;&nbsp;
              <input type="radio" name="rssdesc" value="0" <?php if($row->rssdesc=="0") echo 'CHECKED="checked"'; ?>>
              &nbsp;No</span></td>
        		<td><span class="style3"><strong>Collect  Feed Description</strong></span></td>
   	          </tr>
            <tr>
              <td><span class="style6">Feed Image:</span></td>
              <td><span class="style3">
              <input type="radio" name="rssimage" value="1" <?php if($row->rssimage=="1") echo 'CHECKED="checked"'; ?>>
              &nbsp;Yes&nbsp;&nbsp;
              <input type="radio" name="rssimage" value="0" <?php if($row->rssimage=="0") echo 'CHECKED="checked"'; ?>>
              &nbsp;No</span></td>
        		<td><span class="style3"><strong>Feed Logo image, top right</strong></span> <br />
       		    (if  You set this to Yes, this image will  be the first image in content item)</td>
   	          </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Feed Image Width:</span></td>
              <td><input name="feedImageWidth" type="text" value="<?php echo $row->feedImageWidth; ?>" /></td>
                <td><span class="style3"><strong>Feed Logo image</strong></span></td>
   	          </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Feed Image Height:</span></td>
              <td><input name="feedImageHeight" type="text" value="<?php echo $row->feedImageHeight; ?>" /></td>
                <td><span class="style3"><strong>Feed Logo image</strong></span></td>
   	          </tr>
        	<tr>
        	  <td>&nbsp;</td>
        		<td><span class="style6">Number of Items:</span></td>
              <td><input name="rssitems" type="text" value="<?php echo $row->rssitems; ?>" /></td>
                <td><strong><span class="style3">How  many items to collect from EACH RSS Feed </span><br />
                </strong>(for shared hosting we recommend <strong>15</strong>, and for dedicated up to <strong>200</strong>)</td>
   	          </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Item Title Characterss Count:</span></td>
              <td><input name="rssitemtitle_words" type="text" value="<?php echo $row->rssitemtitle_words; ?>" /></td>
        		<td><span class="style3"><strong>Number of characterss in item title</strong></span> <br />
       		    Title Alias is by default whole title  from the Feed Item. If  You are using SEF component, set &ldquo;Use Title Alias&rdquo; for creating SEF URL&rsquo;s&ndash;recommended  SH404 SEF component </td>
   	          </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Item Description Text:</span></td>
              <td><span class="style3">
              <input type="radio" name="rssitemdesc" value="1" <?php if($row->rssitemdesc=="1") echo 'CHECKED="checked"'; ?>>
              &nbsp;Yes&nbsp;&nbsp;
              <input type="radio" name="rssitemdesc" value="0" <?php if($row->rssitemdesc=="0") echo 'CHECKED="checked"'; ?>>
              &nbsp;No</span></td>
        		<td><span class="style3"><strong>If set to NO, only  Item Titles will be collected</strong></span></td>
   	          </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Item Description Word Count:</span></td>
              <td><input name="rssitemdesc_words" type="text" value="<?php echo $row->rssitemdesc_words; ?>" /></td>
        		<td><span class="style3"><strong>Number of words to  collect from Feed Item</strong></span></td>
   	          </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Item Description Text Images:</span></td>
              <td><span class="style3">
              <input type="radio" name="rssitemdesc_images" value="1" <?php if($row->rssitemdesc_images=="1") echo 'CHECKED="checked"'; ?>>
              &nbsp;Yes&nbsp;&nbsp;
              <input type="radio" name="rssitemdesc_images" value="0" <?php if($row->rssitemdesc_images=="0") echo 'CHECKED="checked"'; ?>>
              &nbsp;No</span></td>
        		<td><span class="style3"><strong>If Feed Item contains images, do You want to collect them,  and insert them in content items </strong></span><br />
       		    Images  are transferred from source item/website&nbsp;  to Your server (images/Rss2Content folder), and inserted&nbsp; into the content &ndash; this decreases page load time  because images are loaded from Your server </td>
   	          </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Item Word Count:</span></td>
              <td><input name="rssitemwords" type="text" value="<?php echo $row->rssitemwords; ?>" /></td>
        		<td><span class="style3"><strong>Number of words that will be in content&nbsp; &ldquo;Intro  Text&rdquo;</strong></span></td>
   	          </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">RSS Feed Link Target:</span></td>
              <td><span class="style3">
              <input type="radio" name="link_target" value="1" <?php if($row->link_target=="1") echo 'CHECKED="checked"'; ?>>
              &nbsp;New Window&nbsp;&nbsp;
              <input type="radio" name="link_target" value="0" <?php if($row->link_target=="0") echo 'CHECKED="checked"'; ?>>
              &nbsp;Same Window</span></td>
        		<td><span class="style3"><strong>When  the script collects Feed Item text,&nbsp; at the end, inserts &ldquo;Read More&rdquo; (Read whole news on source site) link, &nbsp;that links  to web site where user can read the whole news</strong></span> <br />
       		    (Works only if Add rel='rokbox' to links: NO)</td>
   	          </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Add rel='rokbox' to links:</span></td>
              <td><span class="style3">
              <input type="radio" name="no_follow" value="1" <?php if($row->no_follow=="1") echo 'CHECKED="checked"'; ?>>
              &nbsp;Yes&nbsp;&nbsp;
              <input type="radio" name="no_follow" value="0" <?php if($row->no_follow=="0") echo 'CHECKED="checked"'; ?>>
              &nbsp;No</span></td>
        		<td><span class="style3"><strong>With this effect, you can open external link at the end of each article in new window with mootools effect.</strong></span><br />        		    <strong>DEMO</strong>: Please visit our <a href="http://rss2content.com/demo/" target="_blank">demo page</a> --> navigate to content item --> click on (Read whole news on source site) to see effect in action <br />
       		    For this effect you need to install Joomla 1.5 plugin plg_rokbox-system_1.x.zip, and enable it in joomla back-end!<br />
   		        Download plugin: <a href="http://www.rocketwerx.com/products/rokbox/download" target="_blank">http://www.rocketwerx.com/products/rokbox/download</a> </td>
       	        <td>&nbsp;</td>
            </tr>
           <tr>
             <td>&nbsp;</td>
        		<td><span class="style6">Remove HTML tags:</span></td>
             <td><span class="style3">
             <input type="radio" name="htmlTag" value="1" <?php if($row->htmlTag=="1") echo 'CHECKED="checked"'; ?>>
             &nbsp;Yes&nbsp;&nbsp;
             <input type="radio" name="htmlTag" value="0" <?php if($row->htmlTag=="0") echo 'CHECKED="checked"'; ?>>
             &nbsp;No</span></td>
        		<td><span class="style3"><strong>Some Feed Items contain HTML formatting (Bold, Underline,  Italic, Table, ...)</strong></span></td>
       	        <td>&nbsp;</td>
           </tr>
           </tbody>
           </table>
<?php
			echo $tabs->endPanel();
			echo $tabs->startPanel('Image settings', 'imagesettings-page');
			?>
			<table cellpadding="4" cellspacing="1" border="0" width="100%" class="adminlist">
				
			<thead>
				  <tr><th WIDTH="1%" CLASS="title">&nbsp;</th>
					<th WIDTH="18%" CLASS="title">Name</th>
					<th WIDTH="19%" CLASS="title">Value</th>
					<th width="43%" CLASS="title">Description</th>
					<th width="19%" CLASS="title">&nbsp;</th>
				  </tr>
			</thead>
			<tbody>
            <tr>
              <td bgcolor="#CCCCCC">&nbsp;</td>
              <td colspan="4" valign="middle" bgcolor="#CCCCCC">              <span class="style3"><span class="title"><img src="../components/com_rss2content/images/configimages.png" width="550" height="60" /></span><br />
              ***if width and height fields are blank, images  are inserted in original size<br />
***if only one value is entered, images are inserted with proportional  dimensions (depending on the height or width value)</span></td>
              </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Download images:</span></td>
                <td><span class="style3">
                <input type="radio" name="downloadImage" value="1" <?php if($row->downloadImage=="1") echo 'CHECKED="checked"'; ?>>
                &nbsp;Yes&nbsp;&nbsp;
                <input type="radio" name="downloadImage" value="0" <?php if($row->downloadImage=="0") echo 'CHECKED="checked"'; ?>>
                &nbsp;No</span></td>
        		<td><span class="style3"><strong>Download Images to &quot;images/rss2content&quot; folder<br />
        		</strong></span></td>
       	        <td>&nbsp;</td>
            </tr>
           <tr>
             <td>&nbsp;</td>
        		<td><span class="style6">Image width:</span></td>
                <td><input type="text" name="imageWidth" value="<?php echo $row->imageWidth; ?>" /></td>
        		<td><span class="style3"><strong>of inserted image ***</strong></span></td>
       	        <td>&nbsp;</td>
           </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Image height:</span></td>
                <td><input type="text" name="imageHeight" value="<?php echo $row->imageHeight; ?>" /></td>
        		<td><span class="style3"><strong>of inserted image ***</strong></span></td>
       	        <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Image alt tag:</span></td>
                <td><input type="text" name="imageAlt" value="<?php echo $row->imageAlt; ?>" /></td>
        		<td><span class="style3"><strong>Inserted image Alt tag</strong> </span></td>
       	        <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Image class:</span></td>
                <td><input type="text" name="imageClass" value="<?php echo $row->imageClass; ?>" /></td>
        		<td><span class="style3"><strong>Inserted Image Class tag</strong></span></td>
       	        <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Image hspace:</span></td>
                <td><input type="text" name="imageHspace" value="<?php echo $row->imageHspace; ?>" /></td>
        		<td><span class="style3"><strong>Specifies  the whitespace on left and right side of inserted image (Default: 7)</strong></span></td>
       	        <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Image vspace:</span></td>
                <td><input type="text" name="imageVspace" value="<?php echo $row->imageVspace; ?>" /></td>
        		<td><span class="style3"><strong>Specifies  the whitespace on top and bottom of an inserted image (Default: 1)</strong></span></td>
       	        <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Image align:</span></td>
                <td><input type="text" name="imageAlign" value="<?php echo $row->imageAlign; ?>" /></td>
        		<td><span class="style3"><strong>Inserted image alignment - (Default:  left)</strong></span></td>
       	        <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Image border:</span></td>
                <td><input type="text" name="imageBorder" value="<?php echo $row->imageBorder; ?>" /></td>
        		<td><span class="style3"><strong>Inserted  image border (Default: 0)</strong></span></td>
       	        <td>&nbsp;</td>
            </tr>
           </tbody>
           </table>
      <?php
			echo $tabs->endPanel();
			echo $tabs->startPanel('Filters', 'filters-page');
			?>
			<table cellpadding="4" cellspacing="1" border="0" width="100%" class="adminlist">
				
			<thead>
				  <tr><th WIDTH="1%" CLASS="title">&nbsp;</th>
					<th WIDTH="18%" CLASS="title">Name</th>
					<th WIDTH="19%" CLASS="title">Value</th>
					<th width="43%" CLASS="title">Description</th>
					<th width="19%" CLASS="title">&nbsp;</th>
				  </tr>
			</thead>
			<tbody>
            <tr>
              <td bgcolor="#CCCCCC">&nbsp;</td>
              <td colspan="2" bgcolor="#CCCCCC"><h2 class="style2"><tt><u>FILTERS (BETA)</u> - still under development </tt></h2></td>
              <td bgcolor="#CCCCCC"></td>
              <td bgcolor="#CCCCCC"></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style4">Use Filters:</span></td>
                <td><span class="style4">
                <input type="radio" name="filter" value="1" <?php if($row->filter=="1") echo 'CHECKED="checked"'; ?>>
                &nbsp;Yes&nbsp;&nbsp;
                <input type="radio" name="filter" value="0" <?php if($row->filter=="0") echo 'CHECKED="checked"'; ?>>
                &nbsp;No</span></td>
        		<td></td>
       	        <td></td>
            </tr>
            </tbody>
           </table>
           <?php
			echo $tabs->endPanel();
			echo $tabs->startPanel('Content settings', 'contentsettings-page');
			?>
			<table cellpadding="4" cellspacing="1" border="0" width="100%" class="adminlist">
				
			<thead>
				  <tr><th WIDTH="1%" CLASS="title">&nbsp;</th>
					<th WIDTH="18%" CLASS="title">Name</th>
					<th WIDTH="19%" CLASS="title">Value</th>
					<th width="43%" CLASS="title">Description</th>
					<th width="19%" CLASS="title">&nbsp;</th>
				  </tr>
			</thead>
			<tbody>
            <tr>
              <td bgcolor="#CCCCCC">&nbsp;</td>
              <td colspan="3" bgcolor="#CCCCCC"><span class="title"><img src="../components/com_rss2content/images/configcontent.png" width="550" height="60" /></span></td>
              <td bgcolor="#CCCCCC"></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><span class="style6">Intro or Full text:</span></td>
            <td><span class="style3">
            <input type="radio" name="fullTextIntro" value="0" <?php if($row->fullTextIntro=="0") echo 'CHECKED="checked"'; ?>>
            &nbsp;Intro only&nbsp;&nbsp;
            <input type="radio" name="fullTextIntro" value="1" <?php if($row->fullTextIntro=="1") echo 'CHECKED="checked"'; ?>>
            &nbsp;Intro and Full text</span></td>
            <td><span class="style3"><strong>To show Intro text only or Intro and Full text.</strong></span></td>
            <td>&nbsp;</td>
            </tr>
            
            <tr>
              <td>&nbsp;</td>
              <td><span class="style6">Auto published:</span></td>
            <td><span class="style3">
            <input type="radio" name="autoPublished" value="1" <?php if($row->autoPublished=="1") echo 'CHECKED="checked"'; ?>>
            &nbsp;Yes&nbsp;&nbsp;
            <input type="radio" name="autoPublished" value="0" <?php if($row->autoPublished=="0") echo 'CHECKED="checked"'; ?>>
            &nbsp;No</span></td>
            <td><span class="style3"><strong>Auto  publish content items that Rss2Content component collects</strong></span></td>
            <td>&nbsp;</td>
            </tr>
            
            <tr>
              <td>&nbsp;</td>
            	<td><span class="style6">Show on Frontpage:</span></td>
                <td><span class="style3">
                <input type="radio" name="frontPage" value="1" <?php if($row->frontPage=="1") echo 'CHECKED="checked"'; ?> onclick="document.getElementById('section').style.visibility='visible';">
                &nbsp;Yes&nbsp;&nbsp;
                <input type="radio" name="frontPage" value="0" <?php if($row->frontPage=="0") echo 'CHECKED="checked"'; ?> onclick="hideAll();">
                &nbsp;No</span></td>
                <td><strong><span class="style3">Do  You want to show selected categories on front page. </span><br />
                </strong>Automatically activates &rdquo;show on front page&rdquo; for articles in  selected category/s </td>
                <td>&nbsp;</td>
            </tr>
            <tr style="width:50ptx">
              <td>&nbsp;</td>
            	<td><span class="style6">
           		  Choose categories to show on front page:            		</span></td>
                    
                <td><select name="categories[]" id="categories"  onchange="prikazi();" multiple="multiple">
            		<?php
            		$db	=& JFactory::getDBO();
            		for($i=0;$i<count($sects);$i++){
            			$sect=$sects[$i];
            			
            			$db->setQuery("SELECT * FROM #__categories WHERE section='".$sect->id."'");
						$datas = $db->loadObjectList();
						
            			?>
            			<optgroup label="<?php echo $sect->title ?>">
            			<?php
            			for($j=0;$j<count($datas);$j++){
            				$data=$datas[$j];
            				
            					?><option value="<?php echo $data->id; ?>" <?php if(in_array($data->id,$categories)) echo 'selected="selected"'; ?>><?php echo $data->title; ?></option><?php
            				
						}
            			?>
            			</optgroup>
            			<?php
            		}?>
            		</select></td>
                <td><strong><span class="style3">If  Show on Front page Yes, then select category </span><br />
                </strong>(to select more then one Category hold down  &ldquo;Ctrl&rdquo; and click on desired categories)</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
            	<td>&nbsp;</td>
              	<td><span class="style6">Read more text:</span></td>
            	<td><input type="text" name="readmoreText" value="<?php echo $row->readmoreText;?>" style="width:200px" /></td>
            	<td><span class="style3"><strong>Read more text</strong></span></td>
            	<td>&nbsp;</td>
            </tr>
             <tr>
            	<td>&nbsp;</td>
              	<td><span class="style6">Feed source:</span></td>
            	<td><span class="style3">
                <input type="radio" name="feedsource" value="1" <?php if($row->feedsource=="1") echo 'CHECKED="checked"'; ?> onclick="document.getElementById('feedsourceText').style.visibility='visible';">
                &nbsp;Yes&nbsp;&nbsp;
                <input type="radio" name="feedsource" value="0" <?php if($row->feedsource=="0") echo 'CHECKED="checked"'; ?> onclick="document.getElementById('feedsourceText').style.visibility='hidden';">
                &nbsp;No</span>
                <br /><br /><input type="text" name="feedsourceText" id="feedsourceText" value="<?php echo $row->feedsourceText;?>" <?php if($row->feedsource=="1") echo 'style="width:200px;visibility:visible"'; else echo'style="width:200px;visibility:hidden"';?>  /></td>
            	<td><span class="style3"><strong>Feed source text</strong></span></td>
            	<td>&nbsp;</td>
            </tr>
            <tr>
            	<td>&nbsp;</td>
              	<td><span class="style6">Strip characters:</span></td>
            	<td><input type="text" name="strip" value="<?php echo $row->strip;?>" style="width:400px" /></td>
            	<td><span class="style3"><strong>Characters to strip from feeds, separate with |</strong></span></td>
            	<td>&nbsp;</td>
            </tr>
            <tr>
            	<td>&nbsp;</td>
              	<td><span class="style6">Character replacements list:</span></td>
            	<td><textarea name="replacements" cols="60" rows="5"><?php echo $row->replacements;?></textarea></td>
            	<td><span class="style3"><strong>Characters non accepted in Feeds, such as non-latin or accented, can be replaced as per this replacement table. <br />Format is xxx | yyy for each replacement rule. xxx is the character to be replaced, whereas yyy is the new character. <br />There can be many of this rules, separated by commas (,). Between the old character and the new one, use a | character. <br />Note also that xxx or yyy can be multiple characters, such as in Å’|oe </strong></span></td>
            	<td>&nbsp;</td>
            </tr>
             <tr>
            	<td>&nbsp;</td>
              	<td><span class="style6">Use alias connector:</span></td>
            	<td><span class="style3">
                <input type="radio" name="aliasConnector" value="1" <?php if($row->aliasConnector=="1") echo 'CHECKED="checked"'; ?> onclick="document.getElementById('aliasConnectorText').style.visibility='visible';">
                &nbsp;Yes&nbsp;&nbsp;
                <input type="radio" name="aliasConnector" value="0" <?php if($row->aliasConnector=="0") echo 'CHECKED="checked"'; ?> onclick="document.getElementById('aliasConnectorText').style.visibility='hidden';">
                &nbsp;No</span>
                <br /><br /><input type="text" name="aliasConnectorText" id="aliasConnectorText" value="<?php echo $row->aliasConnectorText;?>" <?php if($row->aliasConnector=="1") echo 'style="width:200px;visibility:visible"'; else echo'style="width:200px;visibility:hidden"';?>  /></td>
            	<td><span class="style3"><strong>Alias connector string</strong></span></td>
            	<td>&nbsp;</td>
           
            </tr>
            </tbody>
           </table>
    <?php
			echo $tabs->endPanel();
			echo $tabs->startPanel('Time & content', 'timesettings-page');
			?>
			<table cellpadding="4" cellspacing="1" border="0" width="100%" class="adminlist">
				
			<thead>
				  <tr><th WIDTH="1%" CLASS="title">&nbsp;</th>
					<th WIDTH="18%" CLASS="title">Name</th>
					<th WIDTH="19%" CLASS="title">Value</th>
					<th width="43%" CLASS="title">Description</th>
					<th width="19%" CLASS="title">&nbsp;</th>
				  </tr>
			</thead>
			<tbody>
			<tr>
			  <td bgcolor="#CCCCCC">&nbsp;</td>
			  <td colspan="3" bgcolor="#CCCCCC"><span class="title"><img src="../components/com_rss2content/images/configtime.png" width="550" height="60" /></span></td>
			  <td bgcolor="#CCCCCC">&nbsp;</td>
			</tr>
			<tr>
			  <td>&nbsp;</td>
        		<td><span class="style6">Archive time:</span></td>
                <td><input type="text" name="archive" value="<?php echo $row->archive; ?>" /></td>
        		<td><strong><span class="style3">Number  of days after the Rss2Content content  items will be archived.</span> <br />
        		</strong>(blank field for never)</td>
       	        <td>&nbsp;</td>
			</tr>
        	<tr>
        	  <td>&nbsp;</td>
        		<td><span class="style6">Delete time:</span></td>
                <td><input type="text" name="deleteTime" value="<?php echo $row->deleteTime; ?>" /></td>
        		<td><strong><span class="style3">Number  of days after the Rss2Content content items are deleted from database</span><br />
        		</strong>(blank field for never)</td>
       	        <td>&nbsp;</td>
        	</tr>
        	<tr>
        	  <td>&nbsp;</td>
        		<td><span class="style6">Time offset:</span></td>
                <td><input type="text" name="timeOffset" value="<?php echo $row->timeOffset; ?>" /></td>
        		<td><span class="style3"><strong>Here  You can set time offset between server and Your country</strong></span></td>
       	        <td>&nbsp;</td>
        	</tr>
             <tr>
              <td>&nbsp;</td>
              <td><span class="style6">Use server time:</span></td>
            <td><span class="style3">
            <input type="radio" name="serverTime" value="1" <?php if($row->serverTime=="1") echo 'CHECKED="checked"'; ?>>
            &nbsp;Yes&nbsp;&nbsp;
            <input type="radio" name="serverTime" value="0" <?php if($row->serverTime=="0") echo 'CHECKED="checked"'; ?>>
            &nbsp;No</span></td>
            <td><span class="style3"><strong>Use server time or feed time</strong></span></td>
            <td>&nbsp;</td>
            </tr>
        	</tbody>
           </table>
  <?php
			echo $tabs->endPanel();
			echo $tabs->startPanel('Script/Banner', 'scriptbanner-page');
			?>
			<table cellpadding="4" cellspacing="1" border="0" width="100%" class="adminlist">
				
			<thead>
				  <tr><th WIDTH="1%" CLASS="title">&nbsp;</th>
					<th WIDTH="18%" CLASS="title">Name</th>
					<th WIDTH="19%" CLASS="title">Value</th>
					<th width="43%" CLASS="title">Description</th>
					<th width="19%" CLASS="title">&nbsp;</th>
				  </tr>
			</thead>
			<tbody>
			
        	<tr>
        	  <td bgcolor="#CCCCCC">&nbsp;</td>
        	  <td colspan="3" background="../components/com_rss2content/images/POZ.gif" bgcolor="#CCCCCC"><span class="title"><img src="../components/com_rss2content/images/configbanner.png" width="550" height="60" /></span></td>
        	  <td background="../components/com_rss2content/images/POZ.gif" bgcolor="#CCCCCC">&nbsp;</td>
        	</tr>
        	<tr>
        	  <td><u><span class="style3"></span></u></td>
        		<td><span class="style6">Script/Banner after news:</span></td>
                <td><textarea rows="10" cols="40" name="textAfter"><?php echo $row->textAfter; ?></textarea>                </td>
        		<td><p class="style3"><strong>Here You can insert advertising code that will be displayed  under the each &ldquo;Rss2Content&rdquo; content  item</strong></p></td>
       	        <td>&nbsp;</td>
        	</tr>
			</tbody>
           </table>
  <?php
			echo $tabs->endPanel();
			echo $tabs->startPanel('RokSlideShow settings', 'rocketsettings-page');
			?>
			<table cellpadding="4" cellspacing="1" border="0" width="100%" class="adminlist">
				
			<thead>
				  <tr><th WIDTH="1%" CLASS="title">&nbsp;</th>
					<th WIDTH="18%" CLASS="title">Name</th>
					<th WIDTH="19%" CLASS="title">Value</th>
					<th width="43%" CLASS="title">Description</th>
					<th width="19%" CLASS="title">&nbsp;</th>
				  </tr>
			</thead>
			<tbody>
            <tr>
              <td bgcolor="#CCCCCC">&nbsp;</td>
              <td colspan="4" bgcolor="#CCCCCC"><span class="style3"><strong><span class="title"><img src="../components/com_rss2content/images/configrok.png" width="550" height="60" /></span><br />
              For this feature, You need RokSlideShow  (mod_rokslideshow) by RocketWerx</strong></span><br />
                <strong>-------------------------------------------------------------------------------------------------------------------------------------------------------</strong><br />
                <span class="style3"><strong>Download RokSlideShow: </strong></span><a href="http://www.rocketwerx.com/products/rokslideshow/download" target="_blank"><strong>http://www.rocketwerx.com/products/rokslideshow/download</strong></a> <br />
                <strong><span class="style3">RokSlideShow Documentation:</span> <a href="http://www.rocketwerx.com/products/rokslideshow/documentation" target="_blank">http://www.rocketwerx.com/products/rokslideshow/documentation </a></strong><br />
                <strong>-------------------------------------------------------------------------------------------------------------------------------------------------------</strong><br />
This feature enables module <strong>RokSlideShow</strong> to display image slide show with short description and  link to content item from selected category.Images are collected and stored in <strong>images/rocket</strong>&nbsp; folder.<br />
After You install module (<strong>mod_rokslideshow</strong>), You need to set &quot;<strong>Image Directory</strong>&quot; path to &quot;<strong>images/rocket</strong>&quot;<br />
On our <a href="http://rss2content.com/demo/" target="_blank">demo site</a> you can see working example of RokSlideShow module (at the bottom of the page), with auto-update. <br />              </td>
          </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Numer of Images:</span></td>
                <td><input type="text" name="imageNumber" value="<?php echo $row->imageNumber; ?>" /></td>
        		<td><p><span class="style3"><strong>Here You can define number of images that the script will  copy to &quot;images/rocket/ folder (script will copy first image in content  item only)</strong></span><br />
                      <strong>EXAMPLE: </strong>&nbsp;If You enter number 3, that means that the  script will copy 3 images from 3 <strong>latest</strong> content items from selected category</p></td>
       	        <td>&nbsp;</td>
            </tr>
        	<tr>
        	  <td>&nbsp;</td>
        		<td><span class="style6">Numer of words:</span></td>
                <td><input type="text" name="wordNumber" value="<?php echo $row->wordNumber; ?>" /></td>
        		<td><p class="style3"><strong>This number defines words that will be used for description  over the image </strong></p></td>
       	        <td>&nbsp;</td>
        	</tr>
            <tr style="width:50ptx">
              <td>&nbsp;</td>
            	<td><span class="style6">
           		  Choose category to use images:            		</span></td>
                    
                <td><select name="modulSection" id="modulSection">
            		<?php
            		$db	=& JFactory::getDBO();
            		for($i=0;$i<count($sects);$i++){
            			$sect=$sects[$i];
            			
            			$db->setQuery("SELECT * FROM #__categories WHERE section='".$sect->id."'");
						$datas = $db->loadObjectList();
						
            			?>
            			<optgroup label="<?php echo $sect->title ?>">
            			<?php
            			for($j=0;$j<count($datas);$j++){
            				$data=$datas[$j];
            				
            					?><option value="<?php echo $data->id; ?>" <?php if($data->id==$row->modulSection) echo 'selected="selected"'; ?>><?php echo $data->title; ?></option><?php
            				
						}
            			?>
            			</optgroup>
            			<?php
            		}?>
            		</select></td>
                <td><p class="style3"><strong>Here You need to select category to use with this feature</strong></p></td>
                <td>&nbsp;</td>
            </tr>
        	<tr><td colspan="5"><hr /></td></tr>
        	</tbody>
        </table>
      	<?php
			echo $tabs->endPanel();
			echo $tabs->startPanel('Twitter settings', 'twetter-page');
		?>
			<table cellpadding="4" cellspacing="1" border="0" width="100%" class="adminlist">
				
			<thead>
				  <tr><th WIDTH="1%" CLASS="title">&nbsp;</th>
					<th WIDTH="18%" CLASS="title">Name</th>
					<th WIDTH="19%" CLASS="title">Value</th>
					<th width="43%" CLASS="title">Description</th>
					<th width="19%" CLASS="title">&nbsp;</th>
				  </tr>
			</thead>
			<tbody>
            <tr>
              <td bgcolor="#CCCCCC">&nbsp;</td>
              <td colspan="4" bgcolor="#CCCCCC"></td>
          </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Twitter username:</span></td>
                <td><input type="text" name="twetter_username" value="<?php echo $row->twetter_username; ?>" /></td>
        		<td>Username to your Twitter.com account</td>
       	        <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
        		<td><span class="style6">Twitter password:</span></td>
                <td><input type="password" name="twetter_password" value="<?php echo $row->twetter_password; ?>" /></td>
        		<td>Password to your Twitter.com account</td>
       	        <td>&nbsp;</td>
            </tr>
        	<tr>
        	  <td>&nbsp;</td>
        		<td><span class="style6">Twitter sections:</span></td>
                <td><select name="twetter_sections[]" multiple="multiple" size="10">
                <?php
					$db	=& JFactory::getDBO();
					$db->setQuery("SELECT * FROM #__sections WHERE published=1");
					$secs=$db->loadObjectList();
					$selectedSections=explode(',',$row->twetter_sections);
					for($i=0;$i<count($secs);$i++){
						$sec=$secs[$i];
						?>
                        <option value="<?php echo $sec->id;?>" <?php if(in_array($sec->id,$selectedSections)) echo 'selected="selected"';?>><?php echo $sec->title;?></option>
                        <?php
					}
				?>
                </select></td>
        		<td>Sections which will be used to update status</td>
       	        <td>&nbsp;</td>
        	</tr>
            <tr>
        	  <td>&nbsp;</td>
        		<td><span class="style6">Twitter categories:</span></td>
                <td><select name="twetter_categories[]" multiple="multiple" size="10">
                <?php
					$db	=& JFactory::getDBO();
					$db->setQuery("SELECT * FROM #__categories WHERE published=1");
					$secs=$db->loadObjectList();
					$selectedCategories=explode(',',$row->twetter_categories);
					for($i=0;$i<count($secs);$i++){
						$sec=$secs[$i];
						?>
                        <option value="<?php echo $sec->id;?>" <?php if(in_array($sec->id,$selectedCategories)) echo 'selected="selected"';?>><?php echo $sec->title;?></option>
                        <?php
					}
				?>
                </select></td>
        		<td>Categories which will be used to update status</td>
       	        <td>&nbsp;</td>
        	</tr>
            <tr>
              <td>&nbsp;</td>
            	<td><span class="style6">Attaching URL to status:</span></td>
                <td><span class="style3">
                <input type="radio" name="twetter_attach" value="1" <?php if($row->twetter_attach=="1") echo 'CHECKED="checked"'; ?> >
                &nbsp;Yes&nbsp;&nbsp;
                <input type="radio" name="twetter_attach" value="0" <?php if($row->twetter_attach=="0") echo 'CHECKED="checked"'; ?> >
                &nbsp;No</span></td>
                <td>Attach address to article when update status</td>
                <td>&nbsp;</td>
            </tr><tr>
              <td>&nbsp;</td>
            	<td><span class="style6">Enable User Layer:</span></td>
                <td><span class="style3">
                <input type="radio" name="twetter_user_layer" value="1" <?php if($row->twetter_user_layer=="1") echo 'CHECKED="checked"'; ?> >
                &nbsp;Yes&nbsp;&nbsp;
                <input type="radio" name="twetter_user_layer" value="0" <?php if($row->twetter_user_layer=="0") echo 'CHECKED="checked"'; ?> >
                &nbsp;No</span></td>
                <td>Enable/Disable user layer that enable/disable Twitter configuration in personal details (user.xml)</td>
                <td>&nbsp;</td>
            </tr>
            
        	<tr><td colspan="5"><hr /></td></tr>
        	</tbody>
        </table>
      	<?php
			echo $tabs->endPanel();
			echo $tabs->endPane();
		?>
        <input type="hidden" name="option" value="<?php echo $option; ?>" />
        
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="act" value="conf" />
        </form>
        
        <?php
	}
	
	function showFilter($option,$rows){
		HTML_Rss2Content::filterMenu();
		?>
		 	<script language='javascript' type='text/javascript'>
			<!--
			function prikazi(){
				for (i=1;i<<?php $n=count($rows);$row=$rows[$n-1];echo $row->id+1;?>;i++){
					if(document.getElementById(i))
						document.getElementById(i).style.visibility="hidden";
				}
				if(document.getElementById('section').value==0){
					for (i=1;i<<?php $n=count($rows);$row=$rows[$n-1];echo $row->id+1;?>;i++){
						if(document.getElementById(i))
							document.getElementById(i).style.visibility="hidden";
					}
					document.getElementById("naslov").style.visibility='hidden';
				}
				else{
					slika=document.getElementById('section').value; 
					document.getElementById("naslov").style.visibility='visible';
					document.getElementById(slika).style.visibility='visible';
				}
				
			}
			//-->
			</script>
				<form action="index2.php" method="post"  name="adminForm" id="adminForm" class="adminForm">
				<table cellpadding="4" cellspacing="0" border="0" width="50%">
				<THEAD>
				<th width="20%" class="title">Choose section:</th>
				<th width="20%" class="title" STYLE="visibility: hidden" id="naslov">Choose category:</th>
				<th></th>
				</THEAD>
				<TBODY>
				<tr>
					<td><select name="section" id="section" STYLE="position:absolute" onchange="prikazi();">
						<option value="0">&nbsp;</option>
					<?php
						for($i=0;$i<count($rows);$i++){
							$row=$rows[$i];
							?><option value="<?php echo $row->id; ?>"><?php echo $row->title; ?></option><?php
						}
					?>
					</select>
					</td>
					<td><?php
						$db	=& JFactory::getDBO();
						for($i=0;$i<count($rows);$i++){
							$row=$rows[$i];
							$db->setQuery("SELECT * FROM #__categories WHERE section='".$row->id."'");
							$datas = $db->loadObjectList();
							?>
							<select name="category<?php echo $row->id;?>" id="<?php echo $row->id;?>" style="visibility:hidden;position:absolute;top:10;right:200">
							<option value="0">&nbsp;</option>
								<?php
								for($j=0;$j<count($datas);$j++){
									$data=$datas[$j];
									?><option value="<?php echo $data->id; ?>"><?php echo $data->title; ?></option><?php
								}
								?>
							</select>
							<?php
						}
					?>
					</td>
					<td></td>
				</tr>
				<tr>
					<td colspan="3">&nbsp</td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" name="izaberiSekcijuiKategoruiju" value="Choose"></td>
					<td></td>
				</tr>
				</TBODY>
			</table>
			<?php
			if(isset($_REQUEST['section'])){
				$section=$_REQUEST['section'];
			}
			if(isset($_REQUEST['section']) && isset($_REQUEST['category'.$section])){
				$db->setQuery("SELECT * FROM #__sections WHERE id='".$_REQUEST['section']."'");
				$ses=$db->loadObjectList();
				$se=$ses[0];
				$db->setQuery("SELECT * FROM #__categories WHERE id='".$_REQUEST['category'.$section]."'");
				$cat=$db->loadObjectList();
				$ca=$cat[0];
				
				$db->setQuery("SELECT * FROM #__rss2content_filter WHERE sectionid='".$_REQUEST['section']."' AND categoryid='".$_REQUEST['category'.$section]."'");
				$filters=$db->loadObjectList();
				echo "Section: ".$se->title." - Category: ".$ca->title;
				?>
				<table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminlist">
				<thead>
				<tr>
					<th width="20"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($filters); ?>);" /></th>
					<th width="20"></th>
					<th class="title" >Filter:</th>
					<th width="20%">Published</th>
				</tr>
				</thead>
				<tbody>
			<?php
			$k = 0;
			for($i=0; $i < count( $filters ); $i++) {
			$fil = $filters[$i];
			$published = JHTML::_('grid.published', $fil, $i );
 			$checked = JHTML::_('grid.id', $i, $fil->id );
	
   			?>
			<tr class="<?php echo "filter$k"; ?>">
			<td><?php echo $checked; ?></td>
			<td>&nbsp;</td>
			<td><a href="#edit" onclick="return listItemTask('cb<?php echo $i;?>','editFilter')"><?php echo $fil->filtertext; ?></a></td>
		    <td align="center">
		    <?php
			if ($fil->published == "1") {
				echo "<a href=\"javascript: void(0);\" onClick=\"return listItemTask('cb$i','unpublishFilter')\"><img src=\"images/tick.png\" border=\"0\" /></a>";
			} else {
				echo "<a href=\"javascript: void(0);\" onClick=\"return listItemTask('cb$i','publishFilter')\"><img src=\"images/publish_x.png\" border=\"0\" /></a>";
			}
   ?>
		    </td>
			<?php $k = 1 - $k; ?>
			</tr>
			<?php 
			} 

			?>
			</tbody>
			</table>
			<input type="hidden" name="category<?php echo $section; ?>" value="<?php echo $_REQUEST['category'.$section]; ?>">
				<input type="hidden" name="section" value="<?php echo $_REQUEST['section']; ?>">
			<?php
			}
			?>
		 	
			<input type="hidden" name="option" value="<?php echo $option; ?>" />
			<input type="hidden" name="task" value="" />
			<input type="hidden" name="act" value="filter" />
			<input type="hidden" name="boxchecked" value="0" />
			</form>
		<?php
	}
	
	function newFilter($option,$rows){
		HTML_Rss2Content::newFilterMenu();
		?>
		 	<script language='javascript' type='text/javascript'>
			<!--
			function prikazi(){
				for (i=1;i<<?php $n=count($rows);$row=$rows[$n-1];echo $row->id+1;?>;i++){
					if(document.getElementById(i))
						document.getElementById(i).style.visibility="hidden";
				}
				if(document.getElementById('section').value==0){
					for (i=1;i<<?php $n=count($rows);$row=$rows[$n-1];echo $row->id+1;?>;i++){
						if(document.getElementById(i))
							document.getElementById(i).style.visibility="hidden";
					}
					document.getElementById("naslov1").style.visibility='hidden';
				}
				else{
					slika=document.getElementById('section').value; 
					document.getElementById("naslov1").style.visibility='visible';
					document.getElementById(slika).style.visibility='visible';
				}
				
			}
			
			function getObject(obj) {
   			 	var strObj;
    			if (document.all) {
      				strObj = document.all.item(obj);
    			} else if (document.getElementById) {
      				strObj = document.getElementById(obj);
    			}
   				return strObj;
  			}
			
			function insertRow() {
    			var oTable = getObject('fieldValuesBody');
   				var oRow, oCell ,oCellCont, oInput;
    			
    			var i, j;
    			i=document.adminForm.valueCount.value;
    			i++;
    			
    			oRow = document.createElement('TR');
    			oTable.appendChild(oRow);

    			oCell = document.createElement('TD');
    
    			oInput=document.createElement('INPUT');
    			oInput.name='filters['+i+']';
    			oInput.setAttribute('mosLabel','Name');
    			oInput.setAttribute('mosReq',0);
    			oCell.appendChild(oInput);
   				
     
    			oRow.appendChild(oCell);
    			oInput.focus();

    			document.adminForm.valueCount.value=i;
  			}
			//-->
			</script>
				<form action="index2.php" method="post"  name="adminForm" id="adminForm" class="adminForm">
				<table cellpadding="4" cellspacing="0" border="0" width="50%">
				<THEAD>
				<th width="20%" class="title">Choose section:</th>
				<th width="20%" class="title" STYLE="visibility: hidden" id="naslov1">Choose category:</th>
				<th></th>
				</THEAD>
				<TBODY>
				<tr>
					<td><select name="section" id="section" STYLE="position:absolute" onchange="prikazi();">
						<option value="0">&nbsp;</option>
					<?php
						for($i=0;$i<count($rows);$i++){
							$row=$rows[$i];
							?><option value="<?php echo $row->id; ?>"><?php echo $row->title; ?></option><?php
						}
					?>
					</select>
					</td>
					<td><?php
						$db	=& JFactory::getDBO();
						for($i=0;$i<count($rows);$i++){
							$row=$rows[$i];
							$db->setQuery("SELECT * FROM #__categories WHERE section='".$row->id."'");
							$datas = $db->loadObjectList();
							?>
							<select name="category<?php echo $row->id;?>" id="<?php echo $row->id;?>" style="visibility:hidden;position:absolute;top:10;right:200">
							<option value="0">&nbsp;</option>
								<?php
								for($j=0;$j<count($datas);$j++){
									$data=$datas[$j];
									?><option value="<?php echo $data->id; ?>"><?php echo $data->title; ?></option><?php
								}
								?>
							</select>
							<?php
						}
					?>
					</td>
					<td></td>
				</tr>
				<tr>
					<td colspan="3">&nbsp</td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" name="izaberiSekcijuiKategoruiju" value="Choose"></td>
					<td></td>
				</tr>
				</TBODY>
			</table>
			<TABLE cellpadding="4" cellspacing="0" border="0" width="100%" class="adminForm">
				<tr><td><hr></td></tr>
			</TABLE>
			<?php
			if(isset($_REQUEST['section'])){
				$section=$_REQUEST['section'];
			}
			if(isset($_REQUEST['section']) && isset($_REQUEST['category'.$section])){
				$db->setQuery("SELECT * FROM #__sections WHERE id='".$_REQUEST['section']."'");
				$ses=$db->loadObjectList();
				$se=$ses[0];
				$db->setQuery("SELECT * FROM #__categories WHERE id='".$_REQUEST['category'.$section]."'");
				$cat=$db->loadObjectList();
				$ca=$cat[0];
				echo "Section: ".$se->title." - Category: ".$ca->title;
				?>
				
				<div id=divValues style="text-align:left;">
				<br /><br />
				<input type=button onclick="insertRow();" value="Add new Filter" />
				<table align=left id="divFieldValues" cellpadding="4" cellspacing="1" border="0" width="100%" class="adminform" >
				<tr>
					<th width="20%">FILTER:</th>
				</tr>
					<tbody id="fieldValuesBody">
				<tr>
					<td><input type="text" name="filters[0]"></td>
				</tr>
				<tr>
					<td></td>
				</tr>
        		
        		</tbody>
				</table>
				</div>
				<input type="hidden" name="category<?php echo $section; ?>" value="<?php echo $_REQUEST['category'.$section]; ?>">
				<input type="hidden" name="section" value="<?php echo $_REQUEST['section']; ?>">
				<?php
			}
			?>
			<input type="hidden" name="valueCount"  />
			<input type="hidden" name="option" value="<?php echo $option; ?>" />
			<input type="hidden" name="task" value="newFilter" />
			<input type="hidden" name="act" value="filter" />
			
			</form>
		<?php
	}
	
	function editFilter($option,$row){
		HTML_Rss2Content::editFilterMenu();
		$section=$_REQUEST['section'];
		?>
		<form action="index2.php" method="post"  name="adminForm" id="adminForm" class="adminForm">
		<table cellpadding="4" cellspacing="0" border="0" width="50%">
			<tr>
				<td>Filter:</td>
				<td><input type="text" name="filter" value="<?php echo $row->filtertext; ?>"></td>
			</tr>
			<tr>
				<td>Published:</td>
				<td><select name="published"><option value="0" <?php if($row->published==0) echo 'selected="selected"'; ?>>No</option><option value="1" <?php if($row->published==1) echo 'selected="selected"'; ?>>Yes</option></select></td>
			</tr>
		</table>
		<input type="hidden" name="category<?php echo $_REQUEST['category'.$section]; ?>" value="<?php echo $row->categoryid; ?>">
		<input type="hidden" name="section" value="<?php echo $row->sectionid; ?>">
		<input type="hidden" name="valueCount"  />
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="act" value="filter" />
		<input type="hidden" name="id" value="<?php echo $row->id; ?>">
		<input type="hidden" name="task" value="" />
		</form>
		<?php
	}
	
	function showRss($option,$rows){
		HTML_Rss2Content::defaultMenu();
		?>
		 	<script language='javascript' type='text/javascript'>
			<!--
			function prikazi(){
				for (i=1;i<<?php $n=count($rows);$row=$rows[$n-1];echo $row->id+1;?>;i++){
					if(document.getElementById(i))
						document.getElementById(i).style.visibility="hidden";
				}
				if(document.getElementById('section').value==0){
					for (i=1;i<<?php $n=count($rows);$row=$rows[$n-1];echo $row->id+1;?>;i++){
						if(document.getElementById(i))
							document.getElementById(i).style.visibility="hidden";
					}
					document.getElementById("naslov").style.visibility='hidden';
				}
				else{
					slika=document.getElementById('section').value; 
					document.getElementById("naslov").style.visibility='visible';
					document.getElementById(slika).style.visibility='visible';
				}
				
			}
			//-->
			</script>
				<form action="index2.php" method="post"  name="adminForm" id="adminForm" class="adminForm">
				<table cellpadding="4" cellspacing="0" border="0" width="50%">
				<THEAD>
				<th width="20%" class="title">Choose section:</th>
				<th width="20%" class="title" STYLE="visibility: hidden" id="naslov">Choose category:</th>
				<th></th>
				</THEAD>
				<TBODY>
				<tr>
					<td><select name="section" id="section" STYLE="position:absolute" onchange="prikazi();">
						<option value="0">&nbsp;</option>
					<?php
						for($i=0;$i<count($rows);$i++){
							$row=$rows[$i];
							?><option value="<?php echo $row->id; ?>"><?php echo $row->title; ?></option><?php
						}
					?>
					</select>
					</td>
					<td><?php
						$db	=& JFactory::getDBO();
						for($i=0;$i<count($rows);$i++){
							$row=$rows[$i];
							$db->setQuery("SELECT * FROM #__categories WHERE section='".$row->id."'");
							$datas = $db->loadObjectList();
							?>
							<select name="category<?php echo $row->id;?>" id="<?php echo $row->id;?>" style="visibility:hidden;position:absolute;top:10;right:200">
							<option value="0">&nbsp;</option>
								<?php
								for($j=0;$j<count($datas);$j++){
									$data=$datas[$j];
									?><option value="<?php echo $data->id; ?>"><?php echo $data->title; ?></option><?php
								}
								?>
							</select>
							<?php
						}
					?>
					</td>
					<td></td>
				</tr>
				<tr>
					<td colspan="3">&nbsp</td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" name="izaberiSekcijuiKategoruiju" value="Choose"></td>
					<td></td>
				</tr>
				</TBODY>
			</table>
			<?php
			if(isset($_REQUEST['section'])){
				$section=$_REQUEST['section'];
			}
			if(isset($_REQUEST['section']) && isset($_REQUEST['category'.$section])){
				$db->setQuery("SELECT * FROM #__sections WHERE id='".$_REQUEST['section']."'");
				$ses=$db->loadObjectList();
				$se=$ses[0];
				$db->setQuery("SELECT * FROM #__categories WHERE id='".$_REQUEST['category'.$section]."'");
				$cat=$db->loadObjectList();
				$ca=$cat[0];
				echo "Section: ".$se->title." - Category: ".$ca->title;
				$db->setQuery("SELECT * FROM #__rss2content WHERE sectionid='".$_REQUEST['section']."' AND categoryid='".$_REQUEST['category'.$section]."' ORDER BY ordering");
				$rsss=$db->loadObjectList();
				
				?>
				<table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminlist">
				<thead>
				<tr>
					<th width="20"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($rsss); ?>);" /></th>
					<th width="20"></th>
					<th class="title" >Url:</th>
                    <th class=" title" width="25%">Author</th>
					<th colspan="2" width="5%">Reorder</th>
					<th width="2%">Order</th>
					<th width="1%"><a href="javascript: saveorder(<?php echo count( $rows )-1; ?>)"><img src="images/filesave.png" border="0" width="16" height="16" alt="Save Order" /></a></th>
					<th width="20%">Published</th>
				</tr>
				</thead>
				<tbody>
			<?php
			$k = 0;
			for($i=0; $i < count( $rsss ); $i++) {
			$rss = $rsss[$i];
			$published = JHTML::_('grid.published', $rss, $i );
 			$checked = JHTML::_('grid.id', $i, $rss->id );
				$db	=& JFactory::getDBO();
				$db->setQuery('SELECT * FROM #__users WHERE id='.$rss->author);
				$users=$db->loadObjectList();
				if(count($users)>0){
					$user=$users[0];
					$auth=$user->name;
				}
				else{
					$auth="";
				}
   			?>
			<tr class="<?php echo "rss$k"; ?>">
			<td><?php echo $checked; ?></td>
			<td>&nbsp;</td>
			<td><a href="#edit" onclick="return listItemTask('cb<?php echo $i;?>','editRss')"><?php echo $rss->url; ?></a></td>
            <td><?php echo $auth; ?></td>
			<td><?php if($i!=0){?><a href="#reorder" onClick="return listItemTask('cb<?php echo $i;?>','orderup')" title="Move Up"><img src="images/uparrow.png" width="12" height="12" border="0" alt="Move Up"></a><?php }?></td>
   			<td><?php if($i!=(count($rsss)-1)){?><a href="#reorder" onClick="return listItemTask('cb<?php echo $i;?>','orderdown')" title="Move Down"><img src="images/downarrow.png" width="12" height="12" border="0" alt="Move Up"><?php }?></a></td>
  			<td colspan="2"><input type="text"name="order[]" size="5" value="<?php echo $rss->ordering;?>" class="text_area" style="text-align: center" /></td>
		    <td align="center">
		    <?php
			if ($rss->published == "1") {
				echo "<a href=\"javascript: void(0);\" onClick=\"return listItemTask('cb$i','unpublish')\"><img src=\"images/tick.png\" border=\"0\" /></a>";
			} else {
				echo "<a href=\"javascript: void(0);\" onClick=\"return listItemTask('cb$i','publish')\"><img src=\"images/publish_x.png\" border=\"0\" /></a>";
			}
   ?>
		    </td>
			<?php $k = 1 - $k; ?>
			</tr>
			<?php 
			} 

			?>
			</tbody>
			</table>
				<input type="hidden" name="category<?php echo $section; ?>" value="<?php echo $_REQUEST['category'.$section]; ?>">
				<input type="hidden" name="section" value="<?php echo $_REQUEST['section']; ?>">
			<?php
			}
			?>
		 	
			<input type="hidden" name="option" value="<?php echo $option; ?>" />
			<input type="hidden" name="task" value="" />
			<input type="hidden" name="act" value="rss" />
			<input type="hidden" name="boxchecked" value="0" />
			</form>
		<?php
		
	}
	
	function newRss($option,$rows,$users){
		HTML_Rss2Content::newRssMenu();
		?>
		 	<script language='javascript' type='text/javascript'>
			<!--
			function prikazi(){
				for (i=1;i<<?php $n=count($rows);$row=$rows[$n-1];echo $row->id+1;?>;i++){
					if(document.getElementById(i))
						document.getElementById(i).style.visibility="hidden";
				}
				if(document.getElementById('section').value==0){
					for (i=1;i<<?php $n=count($rows);$row=$rows[$n-1];echo $row->id+1;?>;i++){
						if(document.getElementById(i))
							document.getElementById(i).style.visibility="hidden";
					}
					document.getElementById("naslov1").style.visibility='hidden';
				}
				else{
					slika=document.getElementById('section').value; 
					document.getElementById("naslov1").style.visibility='visible';
					document.getElementById(slika).style.visibility='visible';
				}
				
			}
			
			function getObject(obj) {
   			 	var strObj;
    			if (document.all) {
      				strObj = document.all.item(obj);
    			} else if (document.getElementById) {
      				strObj = document.getElementById(obj);
    			}
   				return strObj;
  			}
			
			function insertRow() {
    			var oTable = getObject('fieldValuesBody');
   				var oRow, oCell ,oCell1, oInput,oSelect,oOption,theText;
    			
    			var i, j;
    			i=document.adminForm.valueCount.value;
    			i++;
    			
    			oRow = document.createElement('TR');
    			oTable.appendChild(oRow);

    			oCell = document.createElement('TD');
    
    			oInput=document.createElement('INPUT');
    			oInput.name='rsss['+i+']';
    			oInput.setAttribute('mosLabel','Name');
    			oInput.setAttribute('mosReq',0);
				oInput.setAttribute('size',100);
    			oCell.appendChild(oInput);
   				
				oCell1=document.createElement('TD');
				oSelect=document.createElement('SELECT');
				oSelect.name='user['+i+']';
				oOption=document.createElement('OPTION');
				oOption.value='';
				theText=document.createTextNode("")
				oOption.appendChild(theText);
				oSelect.appendChild(oOption);
     			<?php 
					for($j=0;$j<count($users);$j++){
						$user=$users[$j];
						?>
						oOption=document.createElement('OPTION');
						oOption.value='<?php echo $user->id;?>';
						theText=document.createTextNode("<?php echo $user->name;?>");
						oOption.appendChild(theText);
						oSelect.appendChild(oOption);
						<?php
					}
				?>
				
				oCell1.appendChild(oSelect);
				
    			oRow.appendChild(oCell);
				oRow.appendChild(oCell1);
    			oInput.focus();

    			document.adminForm.valueCount.value=i;
  			}
			//-->
			</script>
				<form action="index2.php" method="post"  name="adminForm" id="adminForm" class="adminForm">
				<table cellpadding="4" cellspacing="0" border="0" width="50%">
				<THEAD>
				<th width="20%" class="title">Choose section:</th>
				<th width="20%" class="title" STYLE="visibility: hidden" id="naslov1">Choose category:</th>
				<th></th>
				</THEAD>
				<TBODY>
				<tr>
					<td><select name="section" id="section" STYLE="position:absolute" onchange="prikazi();">
						<option value="0">&nbsp;</option>
					<?php
						for($i=0;$i<count($rows);$i++){
							$row=$rows[$i];
							?><option value="<?php echo $row->id; ?>"><?php echo $row->title; ?></option><?php
						}
					?>
					</select>
					</td>
					<td><?php
						$db	=& JFactory::getDBO();
						for($i=0;$i<count($rows);$i++){
							$row=$rows[$i];
							$db->setQuery("SELECT * FROM #__categories WHERE section='".$row->id."'");
							$datas = $db->loadObjectList();
							?>
							<select name="category<?php echo $row->id;?>" id="<?php echo $row->id;?>" style="visibility:hidden;position:absolute;top:10;right:200">
							<option value="0">&nbsp;</option>
								<?php
								for($j=0;$j<count($datas);$j++){
									$data=$datas[$j];
									?><option value="<?php echo $data->id; ?>"><?php echo $data->title; ?></option><?php
								}
								?>
							</select>
							<?php
						}
					?>
					</td>
					<td></td>
				</tr>
				<tr>
					<td colspan="3">&nbsp</td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" name="izaberiSekcijuiKategoruiju" value="Choose"></td>
					<td></td>
				</tr>
				</TBODY>
			</table>
			<TABLE cellpadding="4" cellspacing="0" border="0" width="100%" class="adminForm">
				<tr><td><hr></td></tr>
			</TABLE>
			<?php
			if(isset($_REQUEST['section'])){
				$section=$_REQUEST['section'];
			}
			if(isset($_REQUEST['section']) && isset($_REQUEST['category'.$section])){
				$db->setQuery("SELECT * FROM #__sections WHERE id='".$_REQUEST['section']."'");
				$ses=$db->loadObjectList();
				$se=$ses[0];
				$db->setQuery("SELECT * FROM #__categories WHERE id='".$_REQUEST['category'.$section]."'");
				$cat=$db->loadObjectList();
				$ca=$cat[0];
				echo "Section: ".$se->title." - Category: ".$ca->title;
				
				?>
				
				<div id=divValues style="text-align:left;">
				<br /><br />
				<input type=button onclick="insertRow();" value="Add new Url" />
				
                <table align=left id="divFieldValues" cellpadding="4" cellspacing="1" border="0" width="100%" class="adminform" >
				<thead>
                <tr>
					<th width="20%" class="title">URL:</th>
                    <th class="title">Author:</th>
				</tr>
                </thead>
					<tbody id="fieldValuesBody">
				<tr>
					<td><input type="text" name="rsss[0]" size="100"></td>
                    <td><select name="user[0]" >
                    <option value=""></option>
                    <?php
					
					for($j=0;$j<count($users);$j++){
						$user=$users[$j];
						?>
                        <option value="<?php echo $user->id; ?>"><?php echo $user->name; ?></option>
                        <?php
					}
					?>                    
                    </select>
                    </td>
				</tr>
				<tr>
					<td></td>
				</tr>
        			<input type="hidden" name="category<?php echo $section; ?>" value="<?php echo $_REQUEST['category'.$section]; ?>">
					<input type="hidden" name="section" value="<?php echo $_REQUEST['section']; ?>">
        		</tbody>
				</table>
				</div>
				
				<?php
			}
			?>
			<input type="hidden" name="valueCount"  />
			<input type="hidden" name="option" value="<?php echo $option; ?>" />
			<input type="hidden" name="task" value="newRss" />
			<input type="hidden" name="act" value="rss" />
			
			</form>
		<?php
	}
	
	function editRss($option,$row){
		HTML_Rss2Content::editRssMenu();
		$section=$_REQUEST['section'];
		?>
		<form action="index2.php" method="post"  name="adminForm" id="adminForm" class="adminForm">
		<table cellpadding="4" cellspacing="0" border="0" width="50%">
			<tr>
				<td>Url:</td>
				<td><input type="text" name="url" value="<?php echo $row->url; ?>"></td>
			</tr>
			<tr>
				<td>Ordering:</td>
				<td><input type="text" name="ordering" value="<?php echo $row->ordering; ?>">
			</tr>
			<tr>
				<td>Published:</td>
				<td><select name="published"><option value="0" <?php if($row->published==0) echo 'selected="selected"'; ?>>No</option><option value="1" <?php if($row->published==1) echo 'selected="selected"'; ?>>Yes</option></select></td>
			</tr>
		</table>
		<input type="hidden" name="category<?php echo $_REQUEST['category'.$section]; ?>" value="<?php echo $row->categoryid; ?>">
		<input type="hidden" name="section" value="<?php echo $row->sectionid; ?>">
		<input type="hidden" name="valueCount"  />
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="act" value="rss" />
		<input type="hidden" name="id" value="<?php echo $row->id; ?>">
		<input type="hidden" name="task" value="" />
		</form>
		<?php	
	}
	
	function showCronTask($option,$data,$_CONFIG){
		HTML_Rss2Content::cronMenu();
		jimport('joomla.html.pane');
		?>
		<form action="index2.php" method="post" name="adminForm"  id="adminForm" class="adminForm" >
		<?php
		$editor=& JFactory::getEditor();
		$editor->getContent('editor1');
		$editor->initialise();
		$tabs	=& JPane::getInstance('tabs');
		echo $tabs->startPane('about');
		echo $tabs->startPanel('About', 'about-page');
		?>
        <table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminform">
		<tr>
			<td valign="top"><p><strong><span class="title"><img src="../components/com_rss2content/images/admincron.png" width="550" height="60" /></span></strong><br />
			  Here you can setup Rss2Content to auto update Joomla content.<br />
              Name of Cron file is <b><?php 
			  $handle=opendir('../components/com_rss2content/cron/');
			  while(!false==($file=readdir($handle))){
			  	if ($file != "." && $file != "..") {
              		$cronFile=$file;
					echo $file;					
        		}
			  }	
			  ?></b>, and path is <b><?php echo getenv("HTTP_HOST")."/components/com_rss2content/cron/$cronFile"; ?></b>.<br />
			  If you don't have access to server-side Cron, You can use this built-in Cron feature.<br />
		    The cronjob is launched at the preset time only if your site gets  visits, each time a user or spider accesses your site you will  have the cron running, with entered configuraion.<br />
		    After you finish with configuration, click on &quot;Save CRON Configuration&quot; button (bottom), then you need to enable Cron (tab &quot;Start/Stop cron&quot;)</p>
		    </td>
		</tr>
        </table>
         <?php
		echo $tabs->endPanel();
		echo $tabs->startPanel('Cron cofiguration', 'config-page');
		?>
        <table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminform">
		<tr>
		  <td colspan="2"><strong><span class="title"><img src="../components/com_rss2content/images/admincron.png" width="550" height="60" /></span></strong></td>
		  <td>&nbsp;</td>
		  </tr>
		<tr>
        	<td width="10%">URL:</td>
          <td width="33%"><input type="text" name="executeurl" value="<?php  echo $data->executeurl;?>"  style="width:250pt"/></td>
          <td width="57%">URL to cron.php (http://www.yoursite/components/com_rss2content/cron.php)</td>
        </tr>
		<tr>
        	<td>Execute with:</td>
            <td><input type="radio" name="fetchwith" value="1" <?php if($data->fetchwith=="1") echo 'CHECKED="checked"'; ?>>
            &nbsp;FOPEN&nbsp;&nbsp;
            <input type="radio" name="fetchwith" value="0" <?php if($data->fetchwith=="0") echo 'CHECKED="checked"'; ?>>
            &nbsp;CURL</td>
            <td>Function to use  (depending on PHP configuration)</td>
        </tr>
        <tr>
        	<td>Log results:</td>
            <td><input type="text" name="storepath" value="<?php  echo $data->storepath;?>" /></td>
            <td>Path to store the log result, complete with filename</td>
        </tr>
        <tr>
        	<td>Log storage</td>
          <td><input type="radio" name="storeas" value="0" <?php if($data->storeas=="0") echo 'CHECKED="checked"'; ?>>
            &nbsp;As log&nbsp;&nbsp;
            <input type="radio" name="storeas" value="1" <?php if($data->storeas=="1") echo 'CHECKED="checked"'; ?>>
            &nbsp;Overwrite&nbsp;&nbsp;
            <input type="radio" name="storeas" value="2" <?php if($data->storeas=="2") echo 'CHECKED="checked"'; ?>>
            &nbsp;Ignore</td>
            <td>How the log will be stored. Or select ignore to drop all log results, no record will be generated</td>
        </tr>
        <tr>
        	<td>Store what ?</td>
            <td><input type="radio" name="savefull" value="0" <?php if($data->savefull=="0") echo 'CHECKED="checked"'; ?>>
            &nbsp;Chunk&nbsp;&nbsp;
            <input type="radio" name="savefull" value="1" <?php if($data->savefull=="1") echo 'CHECKED="checked"'; ?>>
            &nbsp;Full</td>
            <td>Will you store the whole log or only a chunk?</td>
        </tr>
        <tr>
        	<td>Chunk Size</td>
            <td><input type="text" name="chunksize" value="<?php  echo $data->chunksize;?>" /></td>
            <td>Size of the chunk to store as result</td>
        </tr>
        <tr>
        	<td>Execute cron every:</td>
            <td><select name="timeperiod">
            	<option value="900"  <?php if($data->timeperiod=="900") echo 'selected="selected"'; ?>>15 Minutes</option>
                <option value="1800"  <?php if($data->timeperiod=="1800") echo 'selected="selected"'; ?>>30 Minutes</option>
                <option value="2700"  <?php if($data->timeperiod=="2700") echo 'selected="selected"'; ?>>45 Minutes</option>
                <option value="3600"  <?php if($data->timeperiod=="3600") echo 'selected="selected"'; ?>>1 hour</option>
                <option value="7200"  <?php if($data->timeperiod=="7200") echo 'selected="selected"'; ?>>2 hours</option>
                <option value="28800"  <?php if($data->timeperiod=="28800") echo 'selected="selected"'; ?>>8 hours</option>
                <option value="43200"  <?php if($data->timeperiod=="43200") echo 'selected="selected"'; ?>>12 hours</option>
                <option value="86400"  <?php if($data->timeperiod=="86400") echo 'selected="selected"'; ?>>1 day</option>
                <option value="172800"  <?php if($data->timeperiod=="172800") echo 'selected="selected"'; ?>>2 days</option>
                <option value="604800"  <?php if($data->timeperiod=="604800") echo 'selected="selected"'; ?>>7 days</option>
                <option value="1296000"  <?php if($data->timeperiod=="1296000") echo 'selected="selected"'; ?>>15 days</option>
                <option value="2592000"  <?php if($data->timeperiod=="2592000") echo 'selected="selected"'; ?>>30 days</option>
            </select></td>
            <td>Cron execution time (if you have more then 10 rss feeds recommended execution time is >30 min.)</td>
        </tr>	
        <tr>
        <td colspan="3" align="center"><hr /><input name='saveCron' type=submit class="style6" style='color:green;' value='Save CRON Configuration'></td>
        </tr>
        </table>
        <?php
		echo $tabs->endPanel();
		echo $tabs->startPanel('Start/Stop cron', 'start-page');
		?>
        <table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminform">
		<tr>
			<td>
		  <td valign="top">
              <p>- by  clicking&nbsp;&quot;Enable CRON RUN&quot;, the code will be inserted into your template (index.php), so cronjobs  can be launched at their preset time from within your Joomla site<br />
                - by clicking the &quot;Disable CRON RUN&quot;, the code will be removed if you haven't done any modifications to it<br /> 
                <strong>if you get message (could not open &quot;/.../.../index.php&quot;) then you need to make the template index.php file writeable by all users, meaning 777 permissions.</strong></p>
              <p>  <br />
                <?php
          if($_CONFIG['iscron'])
           echo "<input type=submit name='crond1' style='color:red;' value='Disable CRON RUN'>";
          else
           echo "<input type=submit name='crond2' style='color:green;' value='Enable CRON RUN'>";
          ?>
                      </p></td></td>
		</tr>
        </table>
        <?php
		echo $tabs->endPanel();
		echo $tabs->endPane();
		?>
         <input type="hidden" name="option" value="<?php echo $option?>" />
         <input type="hidden" name="task" value="saveCronTask" />
         <input type="hidden" name="id" value="<?php echo $data->id;?>">
         <script>
      //	 eval ("updateform2()");
         </script>
        </form>
        <?php
		
	}
	
	function startService($option){
		echo "Rss2Content service started";
		?>
		<form action="index2.php" method="post"  name="adminForm" id="adminForm" class="adminForm">
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		</form>
		<?php
	}
	
	function stopService($option){
		echo "Rss2Content service stoped";
		?>
		<form action="index2.php" method="post"  name="adminForm" id="adminForm" class="adminForm">
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		</form>
		<?php
	}
	
	function manualLoadRss($option,$feeds,$downloaded,$twittered){
		jimport('joomla.application.component.controller');
		?>
		<form action="index2.php" method="post"  name="adminForm" id="adminForm" class="adminForm">
		<table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminlist">
				<thead>
				<tr>
					<th width="20" class="title">No</th>
					<th class="title">Rss</th>
					<th class="title" >Loaded Feeds</th>
					<th class="title">Publish on twitter</th>
				</tr>
				</thead>
				<tbody>              
                <?php
					for($i=0;$i<count($feeds);$i++){
					?>
                    <tr>
                    	<td><?php echo $i+1;?></td>
                        <td><?php echo $feeds[$i];?></td>
                        <td><?php echo $downloaded[$i];?></td>
                        <td><?php echo $twittered[$i];?></td>
                    </tr>
                    <?php
					}
				?>
                </tbody>
         </table>
		<?php
		//$number=Rss2ContentController::getFeed();
		
	//	Rss2ContentController::getSelectedImages();
	//	@require(JPATH_SITE."/components/com_rss2content/cron.php");
		?>
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		</form>
		<?php
	}
	
	function configurationMenu(){
		JToolBarHelper::title( 'Configuration menu', 'config.png');
		JToolBarHelper::back();
		JToolBarHelper::custom('saveConfiguration','save.png','save_f2.png','Save',false);
	}
	
	function defaultMenu(){
		JToolBarHelper::title('Rss2Content menu','menumgr.png');
		JToolBarHelper::publish('publish');
		JToolBarHelper::unpublish('unpublish');
		JToolBarHelper::custom('newRss','new.png','new_f2.png','New Rss',false);
		JToolBarHelper::custom('deleteRss','delete.png','delete_f2.png','Delete',false);
	}
	
	function filterMenu(){
		JToolBarHelper::title('Filter menu','menu.png');
		JToolBarHelper::back();
		JToolBarHelper::custom('newFilter','new.png','new_f2.png','New Filter',false);
		JToolBarHelper::custom('deleteFilter','delete.png','delete_f2.png','Delete',false);
	}
	
	function newFilterMenu(){
		JToolBarHelper::title('New filter menu','menu.png');
		JToolBarHelper::back();
		JToolBarHelper::custom('saveNewFilter','save.png','save_f2.png','Save',false);
	}
	
	function editFilterMenu(){
		JToolBarHelper::title('Edit filter menu','menu.png');
		JToolBarHelper::back();
		JToolBarHelper::custom('saveEditFilter','save.png','save_f2.png','Save',false);
	}
	
	function newRssMenu(){
		JToolBarHelper::title('New Rss menu','menu.png');
		JToolBarHelper::back();
		JToolBarHelper::custom('saveNewRss','save.png','save_f2.png','Save',false);
	}
	
	function editRssMenu(){
		JToolBarHelper::title('Edit rss menu','menu.png');
		JToolBarHelper::back();
		JToolBarHelper::custom('saveEditRss','save.png','save_f2.png','Save',false);
	}
	
	function cronMenu(){
		JToolBarHelper::title('Cron menu','menu.png');
	}
	
	function listMenu(){
		JToolBarHelper::title('List rss menu','menu.png');
		JToolBarHelper::publish('publishAll');
		JToolBarHelper::unpublish('unpublishAll');
		JToolBarHelper::custom('deleteRssAll','delete.png','delete_f2.png','Delete',false);
		JToolBarHelper::back();
	}
}

?>