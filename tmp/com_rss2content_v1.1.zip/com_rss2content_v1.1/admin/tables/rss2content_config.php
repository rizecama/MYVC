<?php

/**
 * @package    Joomla
 * @subpackage Components
 * administrator/com_rss2content/tables/rss2content_config.php
 * @license    GNU/GPL
 * @copyright (C) 2009 rss2content.com
 * @author NenadT <nenadt@gmail.com>
 * @version $Id: rss2content.php,v 1.1 2009/07/22 Exp $
*/

defined( '_JEXEC' ) or die( 'Restricted access' );  
 
 class Rss2ContentConfig extends JTable{
 
 	public $id = null;
 	public $rsstitle = null;
 	public $rssdesc = null;
 	public $rssimage = null;
 	public $rssitems = null;
	public $rssitemtitle_words = null;
 	public $rssitemdesc = null;
 	public $rssitemdesc_words = null;
	public $rssitemdesc_images= null;
	public $link_target= null;
	public $rssitemwords = null;
	public $no_follow = null;
	public $filter = null;
	public $fullTextIntro = null;
	public $autoPublished = null;
	public $frontPage = null;
	public $sectionid = null;
	public $categoryid = null;
	public $readmoreText = null;
	public $feedsource = null;
	public $feedsourceText = null;
	public $archive= null;
	public $deleteTime = null;
	public $timeOffset = null;
	public $textAfter = null;
	public $htmlTag = null;
	public $imageNumber = null;
	public $wordNumber = null;
	public $modulSection = null;
	public $imageWidth = null;
	public $imageHeight =null;
	public $imageAlt =null;
	public $imageClass =null;
	public $imageHspace =null;
	public $imageVspace =null;
	public $imageAlign =null;
	public $imageBorder =null;
	public $downloadImage =null;
	public $feedImageWidth =null;
	public $feedImageHeight =null;
	public $twetter_username =null;
	public $twetter_password =null;
	public $twetter_sections =null;
	public $twetter_categories =null;
	public $twetter_attach =null;
	public $twetter_user_layer =null;
	public $aliasConnector =null;
	public $aliasConnectorText=null;
	public $replacements=null;
	public $strip=null;
 	
 	function __construct(&$db){
		parent::__construct( '#__rss2content_config', 'id', $db );
	}
}
?>