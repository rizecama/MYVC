<?php

/**
 * @package    Joomla
 * @subpackage Components
 * administrator/com_rss2content/tables/rss2content_articles.php
 * @license    GNU/GPL
 * @copyright (C) 2009 rss2content.com
 * @author NenadT <nenadt@gmail.com>
 * @version $Id: rss2content.php,v 1.1 2009/07/22 Exp $
*/

defined( '_JEXEC' ) or die( 'Restricted access' );  
 
 class Rss2ContentArticles extends JTable{
 
 	public $linkId = null;
 	public $articleId = null;
 	public $lastUpdate = null;
 	
 	
 	function __construct(&$db){
		parent::__construct( '#__rss2content_articles', 'id', $db );
	}
}
?>