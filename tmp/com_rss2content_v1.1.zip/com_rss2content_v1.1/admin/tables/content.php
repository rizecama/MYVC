<?php

/**
 * @package    Joomla
 * @subpackage Components
 * administrator/com_rss2content/tables/content.php
 * @license    GNU/GPL
 * @copyright (C) 2009 rss2content.com
 * @author NenadT <nenadt@gmail.com>
 * @version $Id: rss2content.php,v 1.1 2009/07/22 Exp $
*/

defined( '_JEXEC' ) or die( 'Restricted access' );  
 
 class Content extends JTable{
 
 	public $id = null;
 	public $title = null;
 	public $alias = null;
 	public $title_alias = null;
 	public $introtext = null;
	public $fulltext = null;
 	public $state = null;
 	public $sectionid = null;
	public $mask = null;
	public $catid = null;
	public $created = null;
	public $created_by = null;
	public $created_by_alias = null;
	public $modified = null;
	public $modified_by = null;
	public $checked_out = null;
	public $checked_out_time = null;
	public $publish_up = null;
	public $publish_down = null;
	public $images = null;
	public $urls = null;
	public $attribs = null;
	public $version = null;
	public $parentid = null;
	public $ordering = null;
	public $metakey = null;
	public $metadesc = null;
	public $access = null;
	public $hits = null;
	public $metadata = null;
 	
 	function __construct(&$db){
		parent::__construct( '#__content', 'id', $db );
	}
}
?>