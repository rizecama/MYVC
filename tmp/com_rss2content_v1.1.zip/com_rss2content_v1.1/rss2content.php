<?php

/**
 * @package    Joomla
 * @subpackage Components
 * com_rss2content/rss2content.php
 * @license    GNU/GPL
 * @copyright (C) 2009 rss2content.com
 * @author NenadT <nenadt@gmail.com>
 * @version $Id: rss2content.php,v 1.1 2009/07/22 Exp $
*/

defined('_JEXEC') or die();

$post = JRequest::get('post');

?>