<?php

/**
 * @package    Joomla
 * @subpackage Components
 * administrator/com_rss2content/install.rss2content.php
 * @license    GNU/GPL
 * @copyright (C) 2009 rss2content.com
 * @author NenadT <nenadt@gmail.com>
 * @version $Id: rss2content.php,v 1.1 2009/07/22 Exp $
*/

function com_install() {
	if(!is_dir(JPATH_SITE.'/images/rss2content')){
		mkdir(JPATH_SITE.'/images/rss2content');
	}
	
	if(!is_dir(JPATH_SITE.'/images/rocket')){
		mkdir(JPATH_SITE.'/images/rocket');
	}
		
	$db	=& JFactory::getDBO();
	
	$db->setQuery("SHOW COLUMNS FROM #__rss2content");
	$columns=$db->loadObjectList();
	$nemaAutora=false;
	for($i=0;$i<count($columns);$i++){
		if($columns[$i]->Field=='author')
		{
			$nemaAutora=true;
		}
	}
	if(!$nemaAutora){
		$db->setQuery('ALTER TABLE #__rss2content ADD `author` text NOT NULL AFTER `url`');
		$db->query();
	}
	
	$db->setQuery("SHOW COLUMNS FROM #__rss2content_config");
	$columns=$db->loadObjectList();
	$nema=false;
	for($i=0;$i<count($columns);$i++){
		if($columns[$i]->Field=='strip')
		{
			$nema=true;
		}
	}
	if(!$nema){
		$db->setQuery('ALTER TABLE #__rss2content_config 
						ADD `fullTextIntro` tinyint(1) NOT NULL AFTER `filter`,
						ADD `feedsourceText` text NOT NULL AFTER `categoryid`,
						ADD `readmoreText` text NOT NULL AFTER `categoryid`,
			  			ADD `feedsource` tinyint(1) NOT NULL AFTER `categoryid`,			  			
			  			ADD `twetter_username` text NOT NULL AFTER `feedImageHeight`,
			  			ADD `twetter_password` text NOT NULL,
			  			ADD `twetter_sections` text NOT NULL,
			  			ADD `twetter_categories` text NOT NULL,
			  			ADD `twetter_attach` text NOT NULL,
			  			ADD `twetter_user_layer` text NOT NULL,
			  			ADD `aliasConnector` tinyint(1) NOT NULL,
			  			ADD `aliasConnectorText` text NOT NULL,
			  			ADD `replacements` text NOT NULL,
			  			ADD `strip` text NOT NULL,
						ADD `serverTime` tinyint(1) NOT NULL');
		$db->query();
		require_once(JPATH_SITE.'/administrator/components/com_rss2content/tables/rss2content_config.php');
		$config=new Rss2ContentConfig($db);
		$config->id=1;
		$config->fullTextIntro=1;
		$config->readmoreText="(Read whole news on source site)";
		$config->feedsource=1;
		$config->feedsourceText="Source:";
		$config->twetter_attach="0";
		$config->twetter_user_layer="0";
		$config->aliasConnector=0;
		$config->aliasConnectorText="";
		$config->replacements="Å |S, Å’|O, Å½|Z, Å¡|s, Å“|oe, Å¾|z, Å¸|Y, Â¥|Y, Âµ|u, Ã€|A, Ã?|A, Ã‚|A, Ãƒ|A, Ã„|A, Ã…|A, Ã†|A, Ã‡|C, Ãˆ|E, Ã‰|E, ÃŠ|E, Ã‹|E, ÃŒ|I, Ã?|I, ÃŽ|I, Ã?|I, Ã?|D, Ã‘|N, Ã’|O, Ã“|O, Ã”|O, Ã•|O, Ã–|O, Ã˜|O, Ã™|U, Ãš|U, Ã›|U, Ãœ|U, Ã?|Y, ÃŸ|s, Ã |a, Ã¡|a, Ã¢|a, Ã£|a, Ã¤|a, Ã¥|a, Ã¦|a, Ã§|c, Ã¨|e, Ã©|e, Ãª|e, Ã«|e, Ã¬|i, Ã­|i, Ã®|i, Ã¯|i, Ã°|o, Ã±|n, Ã²|o, Ã³|o, Ã´|o, Ãµ|o, Ã¶|o, Ã¸|o, Ã¹|u, Ãº|u, Ã»|u, Ã¼|u, Ã½|y, Ã¿|y, ÃŸ|s";
		$config->strip="â€ž|â€¹|â€™|â€˜|â€œ|â€?|â€¢|â€º|Â«|Â´|Â»|Â°";
		$config->serverTime="0";
		$config->store();
	}
	$db->setQuery("SELECT * from #__rss2content_config");
	$rows=$db->loadObjectList();
	if(count($rows)==0){
		$db->setQuery("INSERT INTO `#__rss2content_config` VALUES (NULL,'1','1','1','5','15','1','25','1','1','10','0','0',1,'1','0','0','0','(Read whole news on source site)',1,'Source:','30','0','0','','0','4','12','','','','','','7','1','left','0',1,'','','','','','','','',0,'','Å |S, Å’|O, Å½|Z, Å¡|s, Å“|oe, Å¾|z, Å¸|Y, Â¥|Y, Âµ|u, Ã€|A, Ã?|A, Ã‚|A, Ãƒ|A, Ã„|A, Ã…|A, Ã†|A, Ã‡|C, Ãˆ|E, Ã‰|E, ÃŠ|E, Ã‹|E, ÃŒ|I, Ã?|I, ÃŽ|I, Ã?|I, Ã?|D, Ã‘|N, Ã’|O, Ã“|O, Ã”|O, Ã•|O, Ã–|O, Ã˜|O, Ã™|U, Ãš|U, Ã›|U, Ãœ|U, Ã?|Y, ÃŸ|s, Ã |a, Ã¡|a, Ã¢|a, Ã£|a, Ã¤|a, Ã¥|a, Ã¦|a, Ã§|c, Ã¨|e, Ã©|e, Ãª|e, Ã«|e, Ã¬|i, Ã­|i, Ã®|i, Ã¯|i, Ã°|o, Ã±|n, Ã²|o, Ã³|o, Ã´|o, Ãµ|o, Ã¶|o, Ã¸|o, Ã¹|u, Ãº|u, Ã»|u, Ã¼|u, Ã½|y, Ã¿|y, ÃŸ|ss','â€ž|â€¹|â€™|â€˜|â€œ|â€?|â€¢|â€º|Â«|Â´|Â»|Â°','0')");
		$db->query();
	}
		
	$db->setQuery("UPDATE #__components SET admin_menu_img='../administrator/components/com_rss2content/images/komponenta_r2c.png'
                                          WHERE admin_menu_link='option=com_rss2content'");
	$db->query();
	$db->setQuery("UPDATE #__components SET admin_menu_img='../administrator/components/com_rss2content/images/config.png'
                                          WHERE admin_menu_link like '%option=com_rss2content%' and admin_menu_link like '%act=conf%'");
	$db->query();
	$db->setQuery("UPDATE #__components SET admin_menu_img='../administrator/components/com_rss2content/images/cron.png'
                                          WHERE admin_menu_link like '%option=com_rss2content%' and admin_menu_link like '%act=cron%'");
	$db->query();
	$db->setQuery("UPDATE #__components SET admin_menu_img='../administrator/components/com_rss2content/images/rss.png'
                                          WHERE admin_menu_link like '%option=com_rss2content%' and admin_menu_link like '%act=rss%'");
	$db->query();
	$db->setQuery("UPDATE #__components SET admin_menu_img='../administrator/components/com_rss2content/images/list.png'
                                          WHERE admin_menu_link like '%option=com_rss2content%' and admin_menu_link like '%act=list%'");
	$db->query();
	$db->setQuery("UPDATE #__components SET admin_menu_img='../administrator/components/com_rss2content/images/filter.png'
                                          WHERE admin_menu_link like '%option=com_rss2content%' and admin_menu_link like '%act=filter%'");
	$db->query();
	$db->setQuery("UPDATE #__components SET admin_menu_img='../administrator/components/com_rss2content/images/manual.png'
                                          WHERE admin_menu_link like '%option=com_rss2content%' and admin_menu_link like '%act=manual%'");
	$db->query();
	$newCronName=getenv("HTTP_HOST").date("dmYHisu").".php";
	rename(JPATH_SITE."/components/com_rss2content/cron/cron.php",JPATH_SITE."/components/com_rss2content/cron/".$newCronName);
	
	$db->setQuery("SELECT * from #__cron_task");
	$rows=$db->loadObjectList();
	if(count($rows)==0){
		$db->setQuery("INSERT INTO `#__cron_task` VALUES (NULL,'http://".getenv("HTTP_HOST")."/components/com_rss2content/cron/".$newCronName."','1','../cache/file.txt','2','0','90','1800')");
		$db->query();
	}
}
?>